import GstWorkspace from "@/components/gst/app"

export default function Page() {
  return <GstWorkspace />
}
