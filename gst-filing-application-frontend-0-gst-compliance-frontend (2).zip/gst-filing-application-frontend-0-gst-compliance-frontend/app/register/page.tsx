import { AuthScreen } from "@/components/gst/auth"

export default function RegisterPage() {
  return <AuthScreen mode="register" />
}
