import { AuthScreen } from "@/components/gst/auth"

export default function LoginPage() {
  return <AuthScreen mode="login" />
}
