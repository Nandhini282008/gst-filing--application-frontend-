export type PageId = "dashboard" | "customers" | "invoices" | "verification" | "calculator" | "returns" | "reports" | "settings" | "profile"

export type UploadReviewStatus = "Needs review" | "Verified" | "Rejected" | "Correction needed"

export type Customer = {
  id: string
  name: string
  contact: string
  email: string
  gstin: string
  business: string
  businessName?: string
  registeredBusinessName?: string
  registrationType?: string
  registrationNumber?: string
  registrationDate?: string
  phone?: string
  address?: string
  city: string
  state: string
  pinCode?: string
  panNumber?: string
  panName?: string
  panDate?: string
  gstRegisteredBusinessName?: string
  gstRegisteredAddress?: string
  gstState?: string
  bankAccountHolder?: string
  bankName?: string
  bankAccountNumber?: string
  bankIfsc?: string
  status: "Active" | "Needs attention" | "Onboarding"
  completion: number
  initials: string
  color: string
}

export type DocumentRecord = {
  id: string
  customer: string
  type: string
  filename: string
  date: string
  status: "Pending" | "Verified" | "Rejected" | "Correction needed"
  size: string
  file?: File
  comment?: string
}

export type CustomerDocumentType =
  | "PAN Card"
  | "GST Registration Certificate"
  | "Business Registration Certificate"
  | "Business Proof"
  | "Business Address Proof"
  | "Udyam Registration Certificate"
  | "Bank Details Proof"
  | "Other Supporting Documents"

export type CustomerDocument = {
  id: string
  customerId: string
  type: CustomerDocumentType
  filename: string
  date: string
  size: string
  status: UploadReviewStatus
  file?: File
  comment?: string
}

export type InvoiceDocumentType =
  | "Sales Invoices"
  | "Purchase Invoices"
  | "Credit Notes"
  | "Debit Notes"
  | "Expense Bills"
  | "E-way Bills"
  | "Other Supporting Documents"

export type InvoiceEntryFields = {
  invoiceNumber: string
  invoiceDate: string
  supplierName: string
  supplierGSTIN: string
  customerName: string
  customerGSTIN: string
  taxableAmount: string
  gstRate: string
  cgst: string
  sgst: string
  igst: string
  totalAmount: string
}

export type InvoiceUpload = {
  id: string
  customerId: string
  type: InvoiceDocumentType
  invoiceKind: "Sales" | "Purchase"
  filename: string
  date: string
  size: string
  status: UploadReviewStatus
  reviewNote: string
  fields: InvoiceEntryFields
  file?: File
  comment?: string
}

export type Invoice = {
  id: string
  number: string
  party: string
  gstin: string
  date: string
  taxable: number
  rate: number
  kind: "Sales" | "Purchase"
  state: "Intra-state" | "Inter-state"
  documentType?: InvoiceDocumentType
  adjustment?: "Credit" | "Debit"
  customerId?: string
  sourceUploadId?: string
}

export const initialCustomers: Customer[] = [
  { id: "GST-2401", name: "Aarav Textiles Pvt. Ltd.", contact: "Riya Mehta", email: "accounts@aaravtextiles.in", gstin: "27AABCA1234F1Z5", business: "Private limited", city: "Mumbai", state: "Maharashtra", status: "Active", completion: 92, initials: "AT", color: "blue" },
  { id: "GST-2402", name: "Bluebird Foods", contact: "Karan Shah", email: "finance@bluebirdfoods.in", gstin: "27AADCB5678K1Z2", business: "Partnership", city: "Pune", state: "Maharashtra", status: "Needs attention", completion: 68, initials: "BF", color: "green" },
  { id: "GST-2403", name: "Northstar Digital", contact: "Ananya Rao", email: "ops@northstardigital.co", gstin: "29AAECN9012P1Z8", business: "Private limited", city: "Bengaluru", state: "Karnataka", status: "Active", completion: 100, initials: "ND", color: "orange" },
  { id: "GST-2404", name: "Cedar & Co. Interiors", contact: "Dev Malhotra", email: "dev@cedarinteriors.in", gstin: "07AAGFC3456R1Z1", business: "Sole proprietorship", city: "New Delhi", state: "Delhi", status: "Onboarding", completion: 42, initials: "CC", color: "purple" },
  { id: "GST-2405", name: "Mira Wellness Studio", contact: "Mira Iyer", email: "hello@mirawellness.in", gstin: "33AAJFM7890C1Z4", business: "Partnership", city: "Chennai", state: "Tamil Nadu", status: "Active", completion: 84, initials: "MW", color: "pink" },
]

export const initialDocuments: DocumentRecord[] = [
  { id: "D-101", customer: "Aarav Textiles Pvt. Ltd.", type: "Sales invoices", filename: "sales_register_may.xlsx", date: "Today, 10:24 AM", status: "Pending", size: "248 KB" },
  { id: "D-102", customer: "Bluebird Foods", type: "Purchase invoices", filename: "purchase_invoices_q1.pdf", date: "Today, 9:12 AM", status: "Correction needed", size: "1.8 MB" },
  { id: "D-103", customer: "Northstar Digital", type: "Bank statement", filename: "hdfc_statement_may.pdf", date: "Yesterday", status: "Verified", size: "640 KB" },
  { id: "D-104", customer: "Mira Wellness Studio", type: "GST registration", filename: "gst_certificate.pdf", date: "May 28, 2025", status: "Verified", size: "920 KB" },
]

export const initialInvoices: Invoice[] = [
  { id: "INV-001", number: "AT-2025-089", party: "Aarav Textiles Pvt. Ltd.", gstin: "27AABCA1234F1Z5", date: "Jun 02, 2025", taxable: 186000, rate: 18, kind: "Sales", state: "Intra-state" },
  { id: "INV-002", number: "BB-25-144", party: "Bluebird Foods", gstin: "27AADCB5678K1Z2", date: "Jun 01, 2025", taxable: 82400, rate: 12, kind: "Sales", state: "Inter-state" },
  { id: "INV-003", number: "NS-INV-512", party: "Northstar Digital", gstin: "29AAECN9012P1Z8", date: "May 30, 2025", taxable: 243000, rate: 18, kind: "Purchase", state: "Inter-state" },
  { id: "INV-004", number: "MW-0182", party: "Mira Wellness Studio", gstin: "33AAJFM7890C1Z4", date: "May 29, 2025", taxable: 51200, rate: 5, kind: "Purchase", state: "Intra-state" },
  { id: "INV-005", number: "CC-2405", party: "Cedar & Co. Interiors", gstin: "07AAGFC3456R1Z1", date: "May 27, 2025", taxable: 129500, rate: 18, kind: "Sales", state: "Inter-state" },
]

export const returnRows = [
  { customer: "Aarav Textiles Pvt. Ltd.", gstin: "27AABCA1234F1Z5", type: "GSTR-1", period: "May 2025", due: "11 Jun 2025", status: "Ready for review" },
  { customer: "Bluebird Foods", gstin: "27AADCB5678K1Z2", type: "GSTR-3B", period: "May 2025", due: "20 Jun 2025", status: "In progress" },
  { customer: "Northstar Digital", gstin: "29AAECN9012P1Z8", type: "GSTR-1", period: "May 2025", due: "11 Jun 2025", status: "Ready for review" },
  { customer: "Cedar & Co. Interiors", gstin: "07AAGFC3456R1Z1", type: "GSTR-3B", period: "May 2025", due: "20 Jun 2025", status: "Not started" },
  { customer: "Mira Wellness Studio", gstin: "33AAJFM7890C1Z4", type: "GSTR-2B", period: "May 2025", due: "14 Jun 2025", status: "Pending payment" },
]

export const formatINR = (value: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value)
