"use client"

import { useRef, useState } from "react"
import { Check, CheckCircle2, CircleAlert, Eye, FileText, RefreshCw, ShieldCheck, Trash2, Upload } from "lucide-react"
import type { Customer, InvoiceDocumentType, InvoiceEntryFields, InvoiceUpload } from "./data"

const acceptedFiles = ".pdf,.xls,.xlsx,.csv,.jpg,.jpeg,.png"
const maximumFileSize = 20 * 1024 * 1024

const documentTypes: InvoiceDocumentType[] = [
  "Sales Invoices",
  "Purchase Invoices",
  "Credit Notes",
  "Debit Notes",
  "Expense Bills",
  "E-way Bills",
  "Other Supporting Documents",
]

const fieldLabels: { key: keyof InvoiceEntryFields; label: string; type: "text" | "date" | "number" }[] = [
  { key: "invoiceNumber", label: "Invoice Number", type: "text" },
  { key: "invoiceDate", label: "Invoice Date", type: "date" },
  { key: "supplierName", label: "Supplier Name", type: "text" },
  { key: "supplierGSTIN", label: "Supplier GSTIN", type: "text" },
  { key: "customerName", label: "Customer Name", type: "text" },
  { key: "customerGSTIN", label: "Customer GSTIN", type: "text" },
  { key: "taxableAmount", label: "Taxable Amount", type: "number" },
  { key: "gstRate", label: "GST Rate", type: "number" },
  { key: "cgst", label: "CGST", type: "number" },
  { key: "sgst", label: "SGST", type: "number" },
  { key: "igst", label: "IGST", type: "number" },
  { key: "totalAmount", label: "Total Invoice Amount", type: "number" },
]

const emptyFields = (): InvoiceEntryFields => ({
  invoiceNumber: "",
  invoiceDate: "",
  supplierName: "",
  supplierGSTIN: "",
  customerName: "",
  customerGSTIN: "",
  taxableAmount: "",
  gstRate: "",
  cgst: "",
  sgst: "",
  igst: "",
  totalAmount: "",
})

function displayFileSize(size: number) {
  return size < 1024 * 1024 ? `${Math.max(1, Math.round(size / 1024))} KB` : `${(size / 1024 / 1024).toFixed(1)} MB`
}

function isSupportedFile(file: File) {
  return /\.(pdf|xls|xlsx|csv|jpg|jpeg|png)$/i.test(file.name) && file.size <= maximumFileSize
}

function previewFile(file?: File) {
  if (!file) return
  const url = URL.createObjectURL(file)
  window.open(url, "_blank", "noopener,noreferrer")
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000)
}

function getInvoiceKind(type: InvoiceDocumentType, fallback: "Sales" | "Purchase"): "Sales" | "Purchase" {
  if (type === "Sales Invoices") return "Sales"
  if (["Purchase Invoices", "Expense Bills"].includes(type)) return "Purchase"
  return fallback
}

export function InvoiceUploadManager({ customers, uploads, defaultKind, onAdd, onUpdate, onRemove, onVerify, notify }: {
  customers: Customer[]
  uploads: InvoiceUpload[]
  defaultKind: "Sales" | "Purchase"
  onAdd: (upload: InvoiceUpload) => void
  onUpdate: (upload: InvoiceUpload) => void
  onRemove: (id: string) => void
  onVerify: (id: string) => void
  notify: (message: string) => void
}) {
  const [customerId, setCustomerId] = useState(customers[0]?.id ?? "")
  const [activeType, setActiveType] = useState<InvoiceDocumentType>(defaultKind === "Sales" ? "Sales Invoices" : "Purchase Invoices")
  const [dragging, setDragging] = useState(false)
  const [replaceId, setReplaceId] = useState<string | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const replaceInput = useRef<HTMLInputElement>(null)

  const addFiles = (files: FileList | null) => {
    if (!files?.length) return
    const customer = customers.find(item => item.id === customerId)
    if (!customer) {
      notify("Add a customer profile before uploading invoice files.")
      return
    }
    const selected = Array.from(files)
    const valid = selected.filter(isSupportedFile)
    if (valid.length !== selected.length) notify("Choose PDF, Excel, CSV, JPG, or PNG files up to 20 MB each.")
    valid.forEach((file, index) => onAdd({
      id: `IU-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 6)}`,
      customerId: customer.id,
      type: activeType,
      invoiceKind: getInvoiceKind(activeType, defaultKind),
      filename: file.name,
      date: "Just now",
      size: displayFileSize(file.size),
      status: "Needs review",
      reviewNote: "Manual entry required",
      fields: emptyFields(),
      file,
    }))
    if (fileInput.current) fileInput.current.value = ""
  }

  const replaceFile = (file?: File) => {
    if (!file || !replaceId) return
    const current = uploads.find(upload => upload.id === replaceId)
    if (!isSupportedFile(file)) notify("Choose a supported file up to 20 MB.")
    else if (current) onUpdate({
      ...current,
      filename: file.name,
      size: displayFileSize(file.size),
      file,
      status: "Needs review",
      reviewNote: "File replaced · review details manually",
      fields: emptyFields(),
    })
    setReplaceId(null)
    if (replaceInput.current) replaceInput.current.value = ""
  }

  const updateField = (upload: InvoiceUpload, key: keyof InvoiceEntryFields, value: string) => {
    onUpdate({ ...upload, status: "Needs review", reviewNote: "Manual entry required", fields: { ...upload.fields, [key]: value } })
  }

  return <section className="panel invoice-upload-panel workflow-panel" aria-labelledby="invoice-uploads-title">
    <div className="panel-head workflow-panel-head">
      <div><h2 id="invoice-uploads-title">Invoice document uploads</h2><p>Attachments stay in this browser session. Enter invoice details manually; documents are never scanned or auto-filled.</p></div>
      <label className="workflow-customer-picker"><span>Registered customer</span><select className="select-button" value={customerId} onChange={event => setCustomerId(event.target.value)}>{customers.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
    </div>
    <div className="workflow-category-grid invoice-category-grid" role="group" aria-label="Invoice document categories">
      {documentTypes.map(type => <button className={`workflow-category ${activeType === type ? "workflow-category-active" : ""}`} type="button" aria-pressed={activeType === type} key={type} onClick={() => setActiveType(type)}><strong>{type}</strong><small>{uploads.filter(upload => upload.type === type).length} uploaded</small></button>)}
    </div>
    <input ref={fileInput} className="sr-only" type="file" multiple accept={acceptedFiles} onChange={event => addFiles(event.target.files)} aria-label={`Upload ${activeType}`} />
    <input ref={replaceInput} className="sr-only" type="file" accept={acceptedFiles} onChange={event => replaceFile(event.target.files?.[0])} aria-label="Replace invoice document" />
    <button className={`workflow-dropzone invoice-dropzone ${dragging ? "workflow-dropzone-active" : ""}`} type="button" onClick={() => fileInput.current?.click()} onDragOver={event => { event.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); addFiles(event.dataTransfer.files) }}>
      <span className="workflow-drop-icon"><Upload size={18} /></span><strong>Drop {activeType.toLowerCase()} here or browse</strong><span>PDF, Excel, CSV, JPG, JPEG, PNG · 20 MB max per file</span>
    </button>
    <p className="workflow-demo-note"><ShieldCheck size={14} /> Frontend demo only. File contents are not scanned, uploaded to a server, or automatically read.</p>
    {uploads.length > 0 && <div className="invoice-upload-list">{uploads.map(upload => {
      const customer = customers.find(item => item.id === upload.customerId)
      const financialDocument = !["E-way Bills", "Other Supporting Documents"].includes(upload.type)
      return <article className="invoice-upload-card" key={upload.id}>
        <div className="invoice-upload-heading"><span className="workflow-file-icon"><FileText size={17} /></span><div className="workflow-file-meta"><strong title={upload.filename}>{upload.filename}</strong><small>{upload.type} · {upload.filename.split(".").pop()?.toUpperCase()} · {upload.size} · {upload.reviewNote}</small></div><span className={`workflow-status ${upload.status === "Verified" ? "workflow-status-verified" : "workflow-status-review"}`}>{upload.status === "Verified" ? <CheckCircle2 size={13} /> : <CircleAlert size={13} />}{upload.status}</span><div className="workflow-document-actions"><button type="button" className="workflow-icon-button" aria-label={`Preview ${upload.filename}`} title="Preview" onClick={() => previewFile(upload.file)}><Eye size={15} /></button><button type="button" className="workflow-icon-button" aria-label={`Replace ${upload.filename}`} title="Replace" onClick={() => { setReplaceId(upload.id); replaceInput.current?.click() }}><RefreshCw size={14} /></button><button type="button" className="workflow-icon-button workflow-remove-button" aria-label={`Remove ${upload.filename}`} title="Remove" onClick={() => onRemove(upload.id)}><Trash2 size={15} /></button></div></div>
        <div className="invoice-upload-controls"><label className="workflow-customer-picker"><span>Customer</span><select className="select-button" value={upload.customerId} disabled={upload.status === "Verified"} onChange={event => { const nextCustomer = customers.find(item => item.id === event.target.value); onUpdate({ ...upload, customerId: event.target.value, invoiceKind: getInvoiceKind(upload.type, upload.invoiceKind), status: "Needs review", reviewNote: "Customer changed · review details", fields: emptyFields() }) }}>{customers.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><span className="invoice-upload-customer">{customer ? `Selected profile: ${customer.name}` : "Select a registered customer"}</span></div>
        <div className="invoice-entry-table-wrap"><table className="invoice-entry-table"><thead><tr>{fieldLabels.map(field => <th key={field.key}>{field.label}</th>)}</tr></thead><tbody><tr>{fieldLabels.map(field => <td key={field.key}><label className="sr-only" htmlFor={`${upload.id}-${field.key}`}>{field.label} for {upload.filename}</label><input id={`${upload.id}-${field.key}`} type={field.type} min={field.type === "number" ? "0" : undefined} step={field.type === "number" ? "0.01" : undefined} value={upload.fields[field.key]} disabled={upload.status === "Verified"} onChange={event => updateField(upload, field.key, event.target.value)} /></td>)}</tr></tbody></table></div>
        <div className="invoice-upload-footer"><span>{upload.status === "Verified" ? <><CheckCircle2 size={14} />{financialDocument ? "Verified and added to GST calculation" : "Verified supporting document · excluded from tax totals"}</> : <><ShieldCheck size={14} />Enter invoice details from the document</>}</span>{upload.status !== "Verified" && <button type="button" className="button button-primary button-sm" disabled={!upload.fields.invoiceNumber.trim() || !upload.fields.invoiceDate || !upload.fields.taxableAmount || !upload.fields.gstRate || !upload.customerId} onClick={() => onVerify(upload.id)}><Check size={14} /> Verify &amp; save</button>}</div>
      </article>
    })}</div>}
  </section>
}
