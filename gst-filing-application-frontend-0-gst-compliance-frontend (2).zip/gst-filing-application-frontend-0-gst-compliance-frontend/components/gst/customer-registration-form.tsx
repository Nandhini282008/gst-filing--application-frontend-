"use client"

import { useRef, useState } from "react"
import { Eye, FileText, Trash2, Upload } from "lucide-react"
import type { Customer, CustomerDocument, CustomerDocumentType } from "./data"

type DocumentKey = "Business Registration Certificate" | "Business Address Proof" | "Udyam Registration Certificate" | "PAN Card" | "GST Registration Certificate" | "Bank Details Proof"
type Values = Record<string, string>
type Props = {
  editing: Customer | null
  existingDocuments: CustomerDocument[]
  customersCount: number
  onSave: (customer: Customer, documents: CustomerDocument[], removedDocumentIds: string[]) => void
  onCancel: () => void
  notify: (message: string) => void
}

const documentTypes: DocumentKey[] = ["Business Registration Certificate", "Business Address Proof", "Udyam Registration Certificate", "PAN Card", "GST Registration Certificate", "Bank Details Proof"]
const states = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Delhi", "Jammu and Kashmir", "Ladakh", "Puducherry"]
const acceptedFileTypes = ".pdf,.xls,.xlsx,.csv,.jpg,.jpeg,.png"
const maxFileSize = 20 * 1024 * 1024

function initialValues(customer: Customer | null): Values {
  return {
    name: customer?.name ?? "", email: customer?.email ?? "", phone: customer?.phone ?? "",
    businessName: customer?.businessName ?? "", registeredBusinessName: customer?.registeredBusinessName ?? customer?.businessName ?? "",
    businessType: customer?.business ?? "Proprietorship", contact: customer?.contact === "Client contact" ? "" : customer?.contact ?? "",
    address: customer?.address ?? "", city: customer?.city === "India" ? "" : customer?.city ?? "", state: customer?.state ?? "Maharashtra", pinCode: customer?.pinCode ?? "",
    registrationType: customer?.registrationType ?? "", registrationNumber: customer?.registrationNumber ?? "", registrationDate: customer?.registrationDate ?? "",
    panNumber: customer?.panNumber ?? "", panName: customer?.panName ?? "", panDate: customer?.panDate ?? "",
    gstin: customer?.gstin === "Pending GSTIN" ? "" : customer?.gstin ?? "", gstBusinessName: customer?.gstRegisteredBusinessName ?? "", gstAddress: customer?.gstRegisteredAddress ?? "", gstState: customer?.gstState ?? customer?.state ?? "Maharashtra",
    bankAccountHolder: customer?.bankAccountHolder ?? "", bankName: customer?.bankName ?? "", bankAccountNumber: customer?.bankAccountNumber ?? "", bankIfsc: customer?.bankIfsc ?? "",
  }
}

function TextField({ label, name, values, update, type = "text", required = false, wide = false, maxLength, pattern, inputMode, placeholder }: { label: string; name: string; values: Values; update: (name: string, value: string) => void; type?: string; required?: boolean; wide?: boolean; maxLength?: number; pattern?: string; inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"]; placeholder?: string }) {
  return <label className={`form-field ${wide ? "field-wide" : ""}`} htmlFor={name}><span>{label}{required && <b> *</b>}</span><input id={name} name={name} type={type} value={values[name] ?? ""} onChange={event => update(name, event.target.value)} required={required} maxLength={maxLength} pattern={pattern} inputMode={inputMode} placeholder={placeholder} /></label>
}

function SelectField({ label, name, values, update, options }: { label: string; name: string; values: Values; update: (name: string, value: string) => void; options: string[] }) {
  return <label className="form-field" htmlFor={name}><span>{label}</span><select id={name} name={name} value={values[name] ?? ""} onChange={event => update(name, event.target.value)}>{options.map(option => <option key={option} value={option}>{option}</option>)}</select></label>
}

function Section({ number, title, description, children }: { number: string; title: string; description: string; children: React.ReactNode }) {
  return <section className="registration-section" aria-labelledby={`registration-section-${number}`}><div className="registration-section-heading"><span className="registration-section-number">{number}</span><div><h3 id={`registration-section-${number}`}>{title}</h3><p>{description}</p></div></div>{children}</section>
}

function UploadArea({ type, document, error, onSelect, onRemove }: { type: DocumentKey; document: CustomerDocument | null; error: string; onSelect: (file: File) => void; onRemove: () => void }) {
  const input = useRef<HTMLInputElement>(null)
  return <div className="registration-upload-area">
    <input ref={input} className="sr-only" type="file" accept={acceptedFileTypes} aria-label={`Browse files for ${type}`} onChange={event => { const file = event.currentTarget.files?.[0]; if (file) onSelect(file); event.currentTarget.value = "" }} />
    <div className="registration-dropzone" onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); const file = event.dataTransfer.files?.[0]; if (file) onSelect(file) }}>
      <span className="registration-upload-icon"><Upload size={17} /></span><div className="registration-dropzone-copy"><strong>{document ? "Document ready to replace" : `Upload ${type}`}</strong><small>Drag and drop a PDF, Excel, CSV, JPG or PNG file here</small></div>
      <button type="button" className="button button-secondary registration-browse" onClick={() => input.current?.click()}>Browse files</button>
    </div>
    <p className="registration-upload-status" role="status">{document ? "Attached for manual review" : "Not Uploaded · Maximum file size 20 MB"}</p>
    {document && <div className="registration-file-row"><span className="registration-file-icon"><FileText size={16} /></span><span className="registration-file-copy"><strong title={document.filename}>{document.filename}</strong><small>{document.filename.split(".").pop()?.toUpperCase()} · {document.size}</small></span>{document.file && <button type="button" className="registration-file-action" aria-label={`Preview ${document.filename}`} title="Preview" onClick={() => { const url = URL.createObjectURL(document.file!); window.open(url, "_blank", "noopener,noreferrer"); window.setTimeout(() => URL.revokeObjectURL(url), 60000) }}><Eye size={15} /></button>}<button type="button" className="registration-file-action registration-file-remove" aria-label={`Remove ${type}`} title="Remove" onClick={onRemove}><Trash2 size={15} /></button></div>}
    {error && <p className="registration-upload-status registration-upload-error" role="alert">{error}</p>}
  </div>
}

export function CustomerRegistrationForm({ editing, existingDocuments, customersCount, onSave, onCancel, notify }: Props) {
  const [values, setValues] = useState(() => initialValues(editing))
  const [documents, setDocuments] = useState<Record<DocumentKey, CustomerDocument | null>>(() => Object.fromEntries(documentTypes.map(type => [type, existingDocuments.find(document => document.type === type) ?? null])) as Record<DocumentKey, CustomerDocument | null>)
  const [errors, setErrors] = useState<Partial<Record<DocumentKey, string>>>({})
  const [removed, setRemoved] = useState<string[]>([])
  const update = (name: string, value: string) => setValues(previous => ({ ...previous, [name]: value }))
  const upload = (type: DocumentKey, file: File) => {
    if (!/\.(pdf|xls|xlsx|csv|jpg|jpeg|png)$/i.test(file.name) || file.size > maxFileSize) { setErrors(previous => ({ ...previous, [type]: "Choose a PDF, Excel, CSV, JPG or PNG file up to 20 MB." })); return }
    const existing = documents[type]
    const document: CustomerDocument = { id: existing?.id ?? `CD-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, customerId: editing?.id ?? "pending-customer", type: type as CustomerDocumentType, filename: file.name, date: new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), size: file.size < 1048576 ? `${Math.max(1, Math.round(file.size / 1024))} KB` : `${(file.size / 1048576).toFixed(1)} MB`, status: "Needs review", file }
    setDocuments(previous => ({ ...previous, [type]: document })); setRemoved(previous => previous.filter(id => id !== existing?.id)); setErrors(previous => ({ ...previous, [type]: "" }))
  }
  const remove = (type: DocumentKey) => { const document = documents[type]; if (document && existingDocuments.some(item => item.id === document.id)) setRemoved(previous => previous.includes(document.id) ? previous : [...previous, document.id]); setDocuments(previous => ({ ...previous, [type]: null })); setErrors(previous => ({ ...previous, [type]: "" })) }

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const name = values.name.trim()
    if (!name) return
    const id = editing?.id ?? `GST-${String(Date.now()).slice(-4)}`
    const customer: Customer = {
      ...editing,
      id, name, email: values.email.trim(), phone: values.phone.trim(), businessName: values.businessName.trim() || name,
      registeredBusinessName: values.registeredBusinessName.trim(), business: values.businessType || "Proprietorship", contact: values.contact.trim() || "Client contact",
      address: values.address.trim(), city: values.city.trim() || "India", state: values.state || "Maharashtra", pinCode: values.pinCode.trim(),
      registrationType: values.registrationType, registrationNumber: values.registrationNumber, registrationDate: values.registrationDate,
      panNumber: values.panNumber.trim().toUpperCase(), panName: values.panName.trim(), panDate: values.panDate,
      gstin: values.gstin.trim().toUpperCase() || "Pending GSTIN", gstRegisteredBusinessName: values.gstBusinessName.trim(), gstRegisteredAddress: values.gstAddress.trim(), gstState: values.gstState,
      bankAccountHolder: values.bankAccountHolder.trim(), bankName: values.bankName.trim(), bankAccountNumber: values.bankAccountNumber.trim(), bankIfsc: values.bankIfsc.trim().toUpperCase(),
      status: editing?.status ?? "Onboarding", completion: editing?.completion ?? 12, initials: name.split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase(), color: editing?.color ?? ["blue", "green", "orange", "purple", "pink"][customersCount % 5],
    }
    onSave(customer, Object.values(documents).filter((document): document is CustomerDocument => Boolean(document)).map(document => ({ ...document, customerId: id })), removed)
  }

  return <form className="customer-form registration-form" onSubmit={submit}>
    <Section number="01" title="Customer Details" description="Primary contact information for this customer."><div className="registration-fields"><TextField label="Customer name" name="name" values={values} update={update} required placeholder="Full name or customer entity" /><TextField label="Email address" name="email" values={values} update={update} type="email" required placeholder="name@business.com" /><TextField label="Phone number" name="phone" values={values} update={update} type="tel" placeholder="+91 00000 00000" /></div></Section>
    <Section number="02" title="Business Details" description="Business identity and registered operating address."><div className="registration-fields"><TextField label="Business name" name="businessName" values={values} update={update} required /><TextField label="Registered business name" name="registeredBusinessName" values={values} update={update} /><SelectField label="Business type" name="businessType" values={values} update={update} options={["Proprietorship", "Partnership", "LLP", "Private Limited", "Public Limited", "Other"]} /><TextField label="Contact person" name="contact" values={values} update={update} /><TextField label="Business address" name="address" values={values} update={update} wide /><TextField label="City / district" name="city" values={values} update={update} /><SelectField label="State" name="state" values={values} update={update} options={states} /><TextField label="PIN code" name="pinCode" values={values} update={update} inputMode="numeric" maxLength={6} pattern="[0-9]{6}" placeholder="6-digit PIN code" /></div><UploadArea type="Business Address Proof" document={documents["Business Address Proof"]} error={errors["Business Address Proof"] ?? ""} onSelect={file => upload("Business Address Proof", file)} onRemove={() => remove("Business Address Proof")} /></Section>
    <Section number="03" title="Business Registration & Proof" description="Registration details and supporting business documents."><div className="registration-fields"><TextField label="Registration type" name="registrationType" values={values} update={update} placeholder="e.g. ROC, Shop Act" /><TextField label="Registration number" name="registrationNumber" values={values} update={update} /><TextField label="Date of registration" name="registrationDate" values={values} update={update} type="date" /><TextField label="Registered business name" name="registeredBusinessName" values={values} update={update} /></div><UploadArea type="Business Registration Certificate" document={documents["Business Registration Certificate"]} error={errors["Business Registration Certificate"] ?? ""} onSelect={file => upload("Business Registration Certificate", file)} onRemove={() => remove("Business Registration Certificate")} /><UploadArea type="Udyam Registration Certificate" document={documents["Udyam Registration Certificate"]} error={errors["Udyam Registration Certificate"] ?? ""} onSelect={file => upload("Udyam Registration Certificate", file)} onRemove={() => remove("Udyam Registration Certificate")} /></Section>
    <Section number="04" title="PAN Card Details" description="Enter the PAN information before uploading the card."><div className="registration-fields"><TextField label="PAN number" name="panNumber" values={values} update={(name, value) => update(name, value.toUpperCase())} maxLength={10} pattern="[A-Za-z]{5}[0-9]{4}[A-Za-z]" placeholder="ABCDE1234F" /><TextField label="Name as per PAN" name="panName" values={values} update={update} /><TextField label="Date of birth / incorporation" name="panDate" values={values} update={update} type="date" /></div><UploadArea type="PAN Card" document={documents["PAN Card"]} error={errors["PAN Card"] ?? ""} onSelect={file => upload("PAN Card", file)} onRemove={() => remove("PAN Card")} /></Section>
    <Section number="05" title="GST Registration Certificate Details" description="Enter GST certificate details before uploading the certificate."><div className="registration-fields"><TextField label="GSTIN" name="gstin" values={values} update={(name, value) => update(name, value.toUpperCase())} maxLength={15} pattern="[0-9]{2}[A-Za-z0-9]{13}" placeholder="15-character GSTIN" /><TextField label="Registered business name" name="gstBusinessName" values={values} update={update} /><TextField label="Business address" name="gstAddress" values={values} update={update} wide /><SelectField label="State" name="gstState" values={values} update={update} options={states} /></div><UploadArea type="GST Registration Certificate" document={documents["GST Registration Certificate"]} error={errors["GST Registration Certificate"] ?? ""} onSelect={file => upload("GST Registration Certificate", file)} onRemove={() => remove("GST Registration Certificate")} /></Section>
    <Section number="06" title="Bank Details" description="Bank account information and proof for refunds and verification."><div className="registration-fields"><TextField label="Account holder name" name="bankAccountHolder" values={values} update={update} /><TextField label="Bank name" name="bankName" values={values} update={update} /><TextField label="Account number" name="bankAccountNumber" values={values} update={update} inputMode="numeric" /><TextField label="IFSC code" name="bankIfsc" values={values} update={(name, value) => update(name, value.toUpperCase())} maxLength={11} pattern="[A-Za-z]{4}0[A-Za-z0-9]{6}" placeholder="ABCD0123456" /></div><UploadArea type="Bank Details Proof" document={documents["Bank Details Proof"]} error={errors["Bank Details Proof"] ?? ""} onSelect={file => upload("Bank Details Proof", file)} onRemove={() => remove("Bank Details Proof")} /></Section>
    <p className="registration-demo-note">Frontend demo only. Uploaded attachments are not scanned or submitted to a tax portal.</p>
    <div className="form-actions registration-form-actions"><button type="button" className="button button-secondary" onClick={onCancel}>Cancel</button><button type="submit" className="button button-primary">{editing ? "Save Customer" : "Save Customer"}</button></div>
  </form>
}
