"use client"

import { useState } from "react"
import { Activity, Bell, ChevronDown, CircleHelp, FileCheck2, FileSpreadsheet, LayoutDashboard, Menu, Search, Settings, UsersRound, X, Calculator, ChartNoAxesCombined, ShieldCheck } from "lucide-react"
import type { PageId } from "./data"

const mainNav: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "customers", label: "Customers", icon: UsersRound },
  { id: "invoices", label: "Invoice Management", icon: FileSpreadsheet },
  { id: "verification", label: "Verification", icon: ShieldCheck },
  { id: "calculator", label: "GST Calculation", icon: Calculator },
  { id: "returns", label: "GST Returns / Filing", icon: FileCheck2 },
  { id: "reports", label: "Reports", icon: ChartNoAxesCombined },
]

export const pageTitles: Record<PageId, { title: string; subtitle: string }> = {
  dashboard: { title: "Good morning, Riya", subtitle: "Here’s what’s happening across your GST portfolio." },
  customers: { title: "Customers", subtitle: "Manage your clients and their compliance profiles." },
  invoices: { title: "Invoice Management", subtitle: "Review sales and purchases in one place." },
  verification: { title: "Verification", subtitle: "Review customer documents and invoice data before approval." },
  calculator: { title: "GST Calculation", subtitle: "Estimate output tax, eligible ITC and net liability." },
  returns: { title: "GST Returns / Filing", subtitle: "Track return preparation and filing status." },
  reports: { title: "Reports", subtitle: "Useful summaries for your team and customers." },
  settings: { title: "Settings", subtitle: "Manage your team, company profile and preferences." },
  profile: { title: "Customer profile", subtitle: "A consolidated view of customer compliance activity." },
}

export function AppShell({ page, onNavigate, children }: { page: PageId; onNavigate: (page: PageId) => void; children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [query, setQuery] = useState("")
  const title = pageTitles[page]

  const navigate = (id: PageId) => {
    onNavigate(id)
    setMobileOpen(false)
  }

  return <div className="app-frame">
    {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <aside id="primary-sidebar" className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Activity size={20} strokeWidth={2.5} /></div><div><strong>ledgerly</strong><span>GST workspace</span></div><button className="icon-button sidebar-close" aria-label="Close navigation" onClick={() => setMobileOpen(false)}><X size={18} /></button></div>
      <div className="workspace-switch"><div className="workspace-avatar">A</div><div className="workspace-name"><strong>Atlas & Co.</strong><span>CA practice</span></div><ChevronDown size={15} /></div>
      <div className="nav-label">WORKSPACE</div>
      <nav aria-label="Main navigation" className="side-nav">
        {mainNav.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${page === id ? "nav-active" : ""}`} onClick={() => navigate(id)} aria-current={page === id ? "page" : undefined}><Icon size={18} strokeWidth={1.8} /><span>{label}</span></button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><CircleHelp size={17} /></div><div><strong>Need a hand?</strong><span>Visit our help center</span></div><span className="help-arrow">↗</span></div>
        <button className={`nav-item ${page === "settings" ? "nav-active" : ""}`} onClick={() => navigate("settings")}><Settings size={18} strokeWidth={1.8} /><span>Settings</span></button>
        <button className="user-card" onClick={() => navigate("settings")}><div className="user-avatar">RM</div><span className="user-info"><strong>Riya Mehta</strong><span>Administrator</span></span><ChevronDown size={15} /></button>
      </div>
    </aside>
    <div className="main-shell">
      <header className="topbar"><button className="icon-button menu-toggle" aria-label="Open navigation" aria-controls="primary-sidebar" aria-expanded={mobileOpen} onClick={() => setMobileOpen(true)}><Menu size={20} /></button><div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{title.title}</strong></div><div className="topbar-actions"><label className="global-search"><Search size={16} /><input aria-label="Search workspace" placeholder="Search anything..." value={query} onChange={event => setQuery(event.target.value)} /><kbd>⌘ K</kbd></label><button className="icon-button notification-button" aria-label="Notifications"><Bell size={19} /><i /></button><div className="topbar-divider" /><button className="top-avatar" aria-label="Riya Mehta profile" onClick={() => navigate("settings")}>RM</button></div></header>
      <main className="main-content"><div className="page-heading"><div><div className="eyebrow">TUESDAY, JUNE 3, 2025 <span className="eyebrow-dot" /> FY 2025–26</div><h1>{title.title}</h1><p>{title.subtitle}</p></div>{page === "dashboard" && <button className="button button-secondary export-top" onClick={() => navigate("reports")}><ChartNoAxesCombined size={16} /> View reports</button>}</div>{children}<footer className="app-footer"><span>Ledgerly GST workspace</span><span>Frontend demo · Browser-only sample data · No GST filing or payments are submitted</span></footer></main>
    </div>
  </div>
}
