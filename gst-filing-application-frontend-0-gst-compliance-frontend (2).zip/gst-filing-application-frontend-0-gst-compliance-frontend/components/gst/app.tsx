"use client"

import { useEffect, useMemo, useState } from "react"
import { AppShell } from "./shell"
import { DashboardView, CustomerView, InvoiceView, VerificationView, CalculatorView, ReturnsView, ReportsView, SettingsView, ProfileView } from "./views"
import { initialCustomers, initialDocuments, initialInvoices, type Customer, type CustomerDocument, type DocumentRecord, type Invoice, type InvoiceUpload, type PageId } from "./data"

function useBrowserState<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(initialValue)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(key)
      if (saved) setValue(JSON.parse(saved) as T)
    } catch {
      // Ignore invalid or blocked browser storage and keep the sample data available.
    } finally {
      setReady(true)
    }
  }, [key])

  useEffect(() => {
    if (!ready) return
    try {
      window.localStorage.setItem(key, JSON.stringify(value, (property, item) => property === "file" ? undefined : item))
    } catch {
      // Browser storage can be disabled or full; the current in-memory state remains usable.
    }
  }, [key, ready, value])

  return [value, setValue] as const
}

export default function GstWorkspace() {
  const [page, setPage] = useState<PageId>("dashboard")
  const [customers, setCustomers] = useBrowserState("ledgerly-customers", initialCustomers)
  const [documents, setDocuments] = useBrowserState("ledgerly-documents", initialDocuments)
  const [invoices, setInvoices] = useBrowserState("ledgerly-invoices", initialInvoices)
  const [customerDocuments, setCustomerDocuments] = useBrowserState<CustomerDocument[]>("ledgerly-customer-documents", [])
  const [invoiceUploads, setInvoiceUploads] = useBrowserState<InvoiceUpload[]>("ledgerly-invoice-uploads", [])
  const [activeCustomer, setActiveCustomer] = useState<Customer>(initialCustomers[0])
  const [toast, setToast] = useState("")

  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(""), 2800)
  }
  const activeDocs = useMemo(() => documents.filter(document => document.customer === activeCustomer.name), [documents, activeCustomer])
  const openProfile = (customer: Customer) => { setActiveCustomer(customer); setPage("profile") }
  const addCustomer = (customer: Customer) => { setCustomers(previous => [customer, ...previous]); notify("Customer profile created successfully.") }
  const updateCustomer = (customer: Customer) => {
    setCustomers(previous => previous.map(item => item.id === customer.id ? customer : item))
    setActiveCustomer(previous => previous.id === customer.id ? customer : previous)
  }
  const removeCustomer = (customer: Customer) => {
    setCustomers(previous => previous.filter(item => item.id !== customer.id))
    setCustomerDocuments(previous => previous.filter(document => document.customerId !== customer.id))
    setInvoiceUploads(previous => previous.filter(upload => upload.customerId !== customer.id))
    setInvoices(previous => previous.filter(invoice => invoice.customerId !== customer.id && invoice.party !== customer.name))
    setDocuments(previous => previous.filter(document => document.customer !== customer.name))
    if (activeCustomer.id === customer.id) {
      const nextCustomer = customers.find(item => item.id !== customer.id)
      if (nextCustomer) setActiveCustomer(nextCustomer)
      else setPage("customers")
    }
    notify("Customer and related demo records deleted.")
  }
  const addInvoice = (invoice: Invoice) => { setInvoices(previous => [invoice, ...previous]); notify("Invoice added to the register.") }
  const updateInvoice = (invoice: Invoice) => {
    setInvoices(previous => previous.map(item => item.id === invoice.id ? invoice : item))
    notify("Invoice updated.")
  }
  const removeInvoice = (id: string) => {
    const removed = invoices.find(invoice => invoice.id === id)
    setInvoices(previous => previous.filter(item => item.id !== id))
    if (removed?.sourceUploadId) setInvoiceUploads(previous => previous.map(upload => upload.id === removed.sourceUploadId ? { ...upload, status: "Needs review", reviewNote: "Register entry removed · ready for manual review" } : upload))
    notify("Invoice removed.")
  }
  const addCustomerDocument = (document: CustomerDocument) => setCustomerDocuments(previous => [document, ...previous])
  const updateLegacyDocument = (id: string, status: DocumentRecord["status"], comment?: string) => {
    setDocuments(previous => previous.map(document => document.id === id ? { ...document, status, comment } : document))
    notify(status === "Verified" ? "Document verified." : "Verification decision saved.")
  }
  const updateCustomerDocument = (document: CustomerDocument) => {
    const previous = customerDocuments.find(item => item.id === document.id)
    setCustomerDocuments(items => items.map(item => item.id === document.id ? document : item))
    if (previous?.status !== "Verified" && document.status === "Verified") notify("Customer document verified.")
  }
  const removeCustomerDocument = (id: string) => setCustomerDocuments(previous => previous.filter(document => document.id !== id))
  const addInvoiceUpload = (upload: InvoiceUpload) => { setInvoiceUploads(previous => [upload, ...previous]); notify("File attached for manual review.") }
  const updateInvoiceUpload = (upload: InvoiceUpload) => {
    const previous = invoiceUploads.find(item => item.id === upload.id)
    if (previous?.status === "Verified" && upload.status !== "Verified") setInvoices(items => items.filter(invoice => invoice.sourceUploadId !== upload.id))
    setInvoiceUploads(items => items.map(item => item.id === upload.id ? upload : item))
  }
  const removeInvoiceUpload = (id: string) => {
    setInvoiceUploads(previous => previous.filter(upload => upload.id !== id))
    setInvoices(previous => previous.filter(invoice => invoice.sourceUploadId !== id))
    notify("Uploaded document removed from the review list.")
  }
  const verifyInvoiceUpload = (id: string) => {
    const upload = invoiceUploads.find(item => item.id === id)
    if (!upload || upload.status === "Verified") return
    const fields = upload.fields
    const financialDocument = !["E-way Bills", "Other Supporting Documents"].includes(upload.type)
    if (financialDocument) {
      const taxable = Number(fields.taxableAmount)
      const rate = Number(fields.gstRate)
      if (!fields.invoiceNumber.trim() || !fields.invoiceDate || !Number.isFinite(taxable) || taxable < 0 || !Number.isFinite(rate) || rate < 0) {
        notify("Enter a valid invoice number, date, taxable value, and GST rate.")
        return
      }
      const invoice: Invoice = {
        id: `INV-${Date.now()}`,
        number: fields.invoiceNumber.trim(),
        party: upload.invoiceKind === "Sales" ? fields.customerName : fields.supplierName,
        gstin: upload.invoiceKind === "Sales" ? fields.customerGSTIN : fields.supplierGSTIN,
        date: fields.invoiceDate,
        taxable,
        rate,
        kind: upload.invoiceKind,
        state: Number(fields.igst) > 0 ? "Inter-state" : "Intra-state",
        documentType: upload.type,
        adjustment: upload.type === "Credit Notes" ? "Credit" : upload.type === "Debit Notes" ? "Debit" : undefined,
        customerId: upload.customerId,
        sourceUploadId: upload.id,
      }
      setInvoices(previous => [invoice, ...previous])
    }
    setInvoiceUploads(previous => previous.map(item => item.id === id ? { ...item, status: "Verified", comment: undefined } : item))
    notify(financialDocument ? "Invoice verified and added to GST calculation." : "Supporting document verified; it is excluded from GST totals.")
  }

  return <AppShell page={page} onNavigate={setPage}>
    {page === "dashboard" && <DashboardView customers={customers} documents={documents} onNavigate={setPage} onOpenCustomer={openProfile} />}
    {page === "customers" && <CustomerView customers={customers} customerDocuments={customerDocuments} onAdd={addCustomer} onUpdate={updateCustomer} onDelete={removeCustomer} onOpen={openProfile} onAddCustomerDocument={addCustomerDocument} onUpdateCustomerDocument={updateCustomerDocument} onRemoveCustomerDocument={removeCustomerDocument} notify={notify} />}
    {page === "invoices" && <InvoiceView customers={customers} invoices={invoices} uploads={invoiceUploads} onAdd={addInvoice} onUpdate={updateInvoice} onRemove={removeInvoice} onAddUpload={addInvoiceUpload} onUpdateUpload={updateInvoiceUpload} onRemoveUpload={removeInvoiceUpload} onVerifyUpload={verifyInvoiceUpload} notify={notify} />}
    {page === "verification" && <VerificationView customers={customers} documents={documents} customerDocuments={customerDocuments} invoiceUploads={invoiceUploads} onLegacyStatus={updateLegacyDocument} onUpdateCustomerDocument={updateCustomerDocument} onUpdateInvoiceUpload={updateInvoiceUpload} onVerifyInvoiceUpload={verifyInvoiceUpload} />}
    {page === "calculator" && <CalculatorView customers={customers} invoices={invoices} />}
    {page === "returns" && <ReturnsView />}
    {page === "reports" && <ReportsView customers={customers} invoices={invoices} />}
    {page === "settings" && <SettingsView notify={notify} />}
    {page === "profile" && <ProfileView customer={activeCustomer} documents={activeDocs} invoices={invoices.filter(invoice => invoice.party === activeCustomer.name)} onNavigate={setPage} />}
    {toast && <div role="status" className="toast-message"><span className="toast-check">✓</span>{toast}</div>}
  </AppShell>
}
