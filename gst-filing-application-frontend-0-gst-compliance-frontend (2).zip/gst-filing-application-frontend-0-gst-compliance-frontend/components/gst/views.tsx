"use client"

import { useMemo, useState } from "react"
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { ArrowDownLeft, ArrowDownToLine, ArrowRight, ArrowUpRight, BadgeCheck, Banknote, Bell, Building2, CalendarDays, ChartNoAxesCombined, Check, CheckCircle2, ChevronDown, Pencil, ChevronLeft, ChevronRight, CircleAlert, Clock3, Download, Eye, FileCheck2, FileDown, FileSpreadsheet, FileText, FolderOpen, Plus, Search, ShieldCheck, SlidersHorizontal, Trash2, Upload, UsersRound, X } from "lucide-react"
import type { Customer, CustomerDocument, DocumentRecord, Invoice, InvoiceDocumentType, InvoiceUpload, PageId } from "./data"
import { formatINR, initialInvoices, returnRows } from "./data"
import { InvoiceUploadManager } from "./document-workflows"
import { CustomerRegistrationForm } from "./customer-registration-form"

const filingData = [
  { month: "Jan", prepared: 34, pending: 11 }, { month: "Feb", prepared: 42, pending: 8 }, { month: "Mar", prepared: 38, pending: 13 }, { month: "Apr", prepared: 49, pending: 9 }, { month: "May", prepared: 56, pending: 12 }, { month: "Jun", prepared: 21, pending: 19 },
]
const activityData = [
  { initials: "AT", color: "blue", title: "Aarav Textiles", detail: "uploaded sales invoices", time: "10 min ago", icon: Upload },
  { initials: "ND", color: "orange", title: "Northstar Digital", detail: "return summary prepared for review", time: "1 hour ago", icon: CheckCircle2 },
  { initials: "BF", color: "green", title: "Bluebird Foods", detail: "purchase invoices need correction", time: "2 hours ago", icon: CircleAlert },
]
const invoiceTypeOptions: InvoiceDocumentType[] = ["Sales Invoices", "Purchase Invoices", "Credit Notes", "Debit Notes", "Expense Bills", "E-way Bills", "Other Supporting Documents"]

function Button({ children, variant = "primary", className = "", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "quiet" | "danger" }) {
  return <button className={`button button-${variant} ${className}`} {...props}>{children}</button>
}
function Panel({ children, className = "", title, subtitle, action }: { children: React.ReactNode; className?: string; title?: string; subtitle?: string; action?: React.ReactNode }) {
  return <section className={`panel ${className}`}>{(title || action) && <div className="panel-head"><div>{title && <h2>{title}</h2>}{subtitle && <p>{subtitle}</p>}</div>{action}</div>}{children}</section>
}
function Status({ value }: { value: string }) {
  const type = value.toLowerCase().replaceAll(" ", "-")
  return <span className={`status-badge status-${type}`}><i />{value}</span>
}
function Initials({ customer }: { customer: Customer }) { return <span className={`initials initials-${customer.color}`}>{customer.initials}</span> }
function PageActions({ children }: { children: React.ReactNode }) { return <div className="page-actions">{children}</div> }
function EmptyRow({ children, columns = 5 }: { children: React.ReactNode; columns?: number }) { return <tr><td colSpan={columns}><div className="empty-row">{children}</div></td></tr> }
function openFile(file?: File) {
  if (!file) return
  const url = URL.createObjectURL(file)
  window.open(url, "_blank", "noopener,noreferrer")
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000)
}
function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\n")
  const link = document.createElement("a")
  link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }))
  link.download = filename
  link.click()
  URL.revokeObjectURL(link.href)
}

export function DashboardView({ customers, documents, onNavigate, onOpenCustomer }: { customers: Customer[]; documents: DocumentRecord[]; onNavigate: (page: PageId) => void; onOpenCustomer: (customer: Customer) => void }) {
  const dueDocs = documents.filter(document => document.status === "Pending" || document.status === "Correction needed").length
  const stats = [
    { label: "Total customers", value: String(customers.length).padStart(2, "0"), delta: "+12.8%", note: "vs. last month", icon: UsersRound, tone: "blue", trend: "up" },
    { label: "Documents uploaded", value: "1,284", delta: "+8.2%", note: "vs. last month", icon: FolderOpen, tone: "green", trend: "up" },
    { label: "Pending verification", value: String(dueDocs + 6).padStart(2, "0"), delta: "Needs review", note: "4 documents overdue", icon: Clock3, tone: "amber", trend: "neutral" },
    { label: "Returns prepared", value: "86", delta: "+18.4%", note: "this financial year", icon: FileCheck2, tone: "mint", trend: "up" },
  ]
  return <>
    <div className="stats-grid">{stats.map(({ label, value, delta, note, icon: Icon, tone, trend }) => <div className="stat-card" key={label}><div className="stat-top"><span>{label}</span><span className={`stat-icon tone-${tone}`}><Icon size={18} /></span></div><div className="stat-value">{value}</div><div className="stat-foot"><span className={trend === "up" ? "trend-up" : "trend-neutral"}>{trend === "up" && <ArrowUpRight size={13} />}{delta}</span><span>{note}</span></div></div>)}</div>
    <div className="dashboard-grid"><Panel className="chart-panel" title="GST filing overview" subtitle="Return activity across your client portfolio" action={<button className="select-button">Last 6 months <ChevronDown size={14} /></button>}><div className="chart-legend"><span><i className="legend-filed" /> Prepared returns</span><span><i className="legend-pending" /> In progress</span></div><div className="filing-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={filingData} barGap={8} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}><CartesianGrid vertical={false} stroke="#edf0f3" strokeDasharray="4 4" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#9299a5", fontSize: 11 }} dy={10} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#9299a5", fontSize: 11 }} /><Tooltip cursor={{ fill: "#f5f7f8" }} contentStyle={{ borderRadius: 10, border: "1px solid #edf0f3", boxShadow: "0 8px 24px #152f4f12", fontSize: 12 }} /><Bar dataKey="prepared" name="Prepared returns" fill="#237d67" radius={[4, 4, 0, 0]} maxBarSize={24} isAnimationActive={false} /><Bar dataKey="pending" name="In progress" fill="#d9ece6" radius={[4, 4, 0, 0]} maxBarSize={24} isAnimationActive={false} /></BarChart></ResponsiveContainer></div></Panel>
      <Panel className="payable-panel" title="GST payable" subtitle="Across active customer accounts"><div className="payable-amount">₹18,42,650</div><div className="payable-change"><span><ArrowDownLeft size={14} /> 8.4%</span> lower than last month</div><div className="payable-divider" /><div className="payable-row"><span><i className="dot dot-navy" /> Output tax</span><strong>₹26,80,400</strong></div><div className="payable-row"><span><i className="dot dot-green" /> Eligible ITC</span><strong>− ₹8,37,750</strong></div><button className="text-link" onClick={() => onNavigate("calculator")}>View GST calculation <ArrowRight size={14} /></button></Panel>
      <Panel className="activity-panel" title="Recent activity" subtitle="Latest updates from your customers" action={<button className="text-link" onClick={() => onNavigate("customers")}>View all <ArrowRight size={14} /></button>}><div className="activity-list">{activityData.map(({ initials, color, title, detail, time, icon: Icon }) => <div className="activity-item" key={title}><span className={`initials initials-${color}`}>{initials}</span><div className="activity-copy"><div><strong>{title}</strong><span>{time}</span></div><p><Icon size={13} />{detail}</p></div></div>)}</div></Panel>
      <Panel className="deadlines-panel" title="Upcoming deadlines" subtitle="Keep your filings on track" action={<button className="text-link" onClick={() => onNavigate("returns")}>View calendar <ArrowRight size={14} /></button>}><div className="deadline-list"><div className="deadline-item"><span className="deadline-date"><b>11</b><small>JUN</small></span><span className="deadline-info"><strong>GSTR-1 filing</strong><small>18 customers · Outward supplies</small></span><span className="deadline-pill due-soon">8 days</span></div><div className="deadline-item"><span className="deadline-date"><b>14</b><small>JUN</small></span><span className="deadline-info"><strong>GSTR-2B review</strong><small>12 customers · ITC reconciliation</small></span><span className="deadline-pill">11 days</span></div><div className="deadline-item"><span className="deadline-date"><b>20</b><small>JUN</small></span><span className="deadline-info"><strong>GSTR-3B filing</strong><small>18 customers · Summary return</small></span><span className="deadline-pill">17 days</span></div></div></Panel>
    </div>
    <Panel className="customers-panel" title="Your customers" subtitle="A quick look at active client compliance" action={<Button variant="secondary" onClick={() => onNavigate("customers")}>View all customers <ArrowRight size={15} /></Button>}><div className="table-wrap"><table><thead><tr><th>Customer</th><th>GSTIN</th><th>Compliance</th><th>Documents</th><th>Status</th><th /></tr></thead><tbody>{customers.slice(0, 4).map(customer => <tr key={customer.id} className="clickable-row" onClick={() => onOpenCustomer(customer)}><td><div className="customer-cell"><Initials customer={customer} /><span><strong>{customer.name}</strong><small>{customer.id}</small></span></div></td><td className="mono-text">{customer.gstin}</td><td><div className="progress-cell"><div className="mini-progress"><span style={{ width: `${customer.completion}%` }} /></div><small>{customer.completion}%</small></div></td><td>{customer.completion === 100 ? "All received" : `${Math.ceil((100 - customer.completion) / 11)} missing`}</td><td><Status value={customer.status} /></td><td><button className="row-arrow" aria-label={`Open ${customer.name}`}><ChevronRight size={16} /></button></td></tr>)}</tbody></table></div></Panel>
  </>
}

export function CustomerView({ customers, customerDocuments, onAdd, onUpdate, onDelete, onOpen, onAddCustomerDocument, onUpdateCustomerDocument, onRemoveCustomerDocument, notify }: { customers: Customer[]; customerDocuments: CustomerDocument[]; onAdd: (customer: Customer) => void; onUpdate: (customer: Customer) => void; onDelete: (customer: Customer) => void; onOpen: (customer: Customer) => void; onAddCustomerDocument: (document: CustomerDocument) => void; onUpdateCustomerDocument: (document: CustomerDocument) => void; onRemoveCustomerDocument: (id: string) => void; notify: (message: string) => void }) {
  const [search, setSearch] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Customer | null>(null)
  const [filter, setFilter] = useState("All customers")
  const filtered = customers.filter(customer => `${customer.name} ${customer.gstin} ${customer.contact}`.toLowerCase().includes(search.toLowerCase()) && (filter === "All customers" || customer.status === filter))
  const saveRegistration = (record: Customer, savedDocuments: CustomerDocument[], removedDocumentIds: string[]) => {
    if (editing) { onUpdate(record); notify("Customer profile updated.") } else onAdd(record)
    const existingDocumentIds = new Set(customerDocuments.filter(document => document.customerId === record.id).map(document => document.id))
    savedDocuments.forEach(document => existingDocumentIds.has(document.id) ? onUpdateCustomerDocument(document) : onAddCustomerDocument(document))
    removedDocumentIds.forEach(onRemoveCustomerDocument)
    setShowForm(false)
    setEditing(null)
  }
  return <>
    <div className="toolbar-row"><div className="search-field"><Search size={16} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search customers..." aria-label="Search customers" /></div><div className="toolbar-controls"><select className="select-button" value={filter} onChange={event => setFilter(event.target.value)} aria-label="Filter customer status"><option>All customers</option><option>Active</option><option>Needs attention</option><option>Onboarding</option></select><Button variant="secondary" onClick={() => downloadCsv("gst-customers.csv", [["Customer ID", "Customer", "GSTIN", "Business type", "Contact", "Email", "City", "State", "Status"], ...filtered.map(customer => [customer.id, customer.name, customer.gstin, customer.business, customer.contact, customer.email, customer.city, customer.state, customer.status])])}><Download size={15} /> Export</Button><Button onClick={() => { setEditing(null); setShowForm(value => !value) }}><Plus size={16} /> Add customer</Button></div></div>
    {showForm && <Panel className="form-panel" title={editing ? "Edit customer" : "New customer profile"} subtitle="Enter the business details needed for GST compliance" action={<button className="icon-button" aria-label="Close form" onClick={() => setShowForm(false)}><X size={18} /></button>}><CustomerRegistrationForm key={editing?.id ?? "new"} editing={editing} existingDocuments={customerDocuments.filter(document => document.customerId === editing?.id)} customersCount={customers.length} onSave={saveRegistration} onCancel={() => { setShowForm(false); setEditing(null) }} notify={notify} /></Panel>}
    <div className="customer-summary-grid"><div className="summary-mini"><span className="summary-icon tone-blue"><UsersRound size={17} /></span><div><strong>{customers.length}</strong><small>Total customers</small></div></div><div className="summary-mini"><span className="summary-icon tone-green"><BadgeCheck size={17} /></span><div><strong>{customers.filter(customer => customer.status === "Active").length}</strong><small>Active</small></div></div><div className="summary-mini"><span className="summary-icon tone-amber"><CircleAlert size={17} /></span><div><strong>{customers.filter(customer => customer.status === "Needs attention").length}</strong><small>Need attention</small></div></div><div className="summary-mini"><span className="summary-icon tone-purple"><Clock3 size={17} /></span><div><strong>{customers.filter(customer => customer.status === "Onboarding").length}</strong><small>Onboarding</small></div></div></div>
    <Panel className="table-panel" title="All customers" subtitle={`${filtered.length} customer profiles`}><div className="table-wrap"><table><thead><tr><th>Customer</th><th>GSTIN</th><th>Business type</th><th>Compliance</th><th>Status</th><th>Contact</th><th /></tr></thead><tbody>{filtered.length ? filtered.map(customer => <tr key={customer.id} className="clickable-row" onClick={() => onOpen(customer)}><td><div className="customer-cell"><Initials customer={customer} /><span><strong>{customer.name}</strong><small>{customer.id} · {customer.city}</small></span></div></td><td className="mono-text">{customer.gstin}</td><td>{customer.business}</td><td><div className="progress-cell"><div className="mini-progress"><span style={{ width: `${customer.completion}%` }} /></div><small>{customer.completion}%</small></div></td><td><Status value={customer.status} /></td><td>{customer.contact}</td><td><div className="row-actions"><button className="row-action" aria-label={`Edit ${customer.name}`} onClick={event => { event.stopPropagation(); setEditing(customer); setShowForm(true) }}><Pencil size={15} /></button><button className="row-action" aria-label={`Delete ${customer.name}`} onClick={event => { event.stopPropagation(); if (window.confirm(`Delete ${customer.name} and its related demo records?`)) onDelete(customer) }}><Trash2 size={15} /></button><button className="row-arrow" aria-label={`View ${customer.name}`} onClick={event => { event.stopPropagation(); onOpen(customer) }}><ChevronRight size={16} /></button></div></td></tr>) : <EmptyRow columns={7}>No customers match that search.</EmptyRow>}</tbody></table></div></Panel>
  </>
}

export function InvoiceView({ customers, invoices, uploads, onAdd, onUpdate, onRemove, onAddUpload, onUpdateUpload, onRemoveUpload, onVerifyUpload, notify }: { customers: Customer[]; invoices: Invoice[]; uploads: InvoiceUpload[]; onAdd: (invoice: Invoice) => void; onUpdate: (invoice: Invoice) => void; onRemove: (id: string) => void; onAddUpload: (upload: InvoiceUpload) => void; onUpdateUpload: (upload: InvoiceUpload) => void; onRemoveUpload: (id: string) => void; onVerifyUpload: (id: string) => void; notify: (message: string) => void }) {
  const [kind, setKind] = useState<"Sales" | "Purchase">("Sales")
  const [search, setSearch] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Invoice | null>(null)
  const [customerFilter, setCustomerFilter] = useState("All customers")
  const [typeFilter, setTypeFilter] = useState<InvoiceDocumentType | "All types">("All types")
  const [yearFilter, setYearFilter] = useState("All financial years")
  const getFinancialYear = (dateValue: string) => {
    const date = new Date(dateValue)
    if (Number.isNaN(date.getTime())) return "Unknown year"
    const startYear = date.getMonth() >= 3 ? date.getFullYear() : date.getFullYear() - 1
    return `FY ${startYear}-${String((startYear + 1) % 100).padStart(2, "0")}`
  }
  const getDocumentType = (invoice: Invoice): InvoiceDocumentType => invoice.documentType ?? (invoice.kind === "Sales" ? "Sales Invoices" : "Purchase Invoices")
  const yearOptions = Array.from(new Set(invoices.map(invoice => getFinancialYear(invoice.date)))).filter(year => year !== "Unknown year").sort().reverse()
  const visible = invoices.filter(invoice => {
    const invoiceCustomerId = invoice.customerId ?? customers.find(customer => customer.name === invoice.party)?.id
    return invoice.kind === kind
      && (customerFilter === "All customers" || invoiceCustomerId === customerFilter)
      && (typeFilter === "All types" || getDocumentType(invoice) === typeFilter)
      && (yearFilter === "All financial years" || getFinancialYear(invoice.date) === yearFilter)
      && `${invoice.number} ${invoice.party} ${invoice.gstin}`.toLowerCase().includes(search.toLowerCase())
  })
  const total = visible.reduce((sum, invoice) => sum + invoice.taxable * (1 + invoice.rate / 100) * (invoice.adjustment === "Credit" ? -1 : 1), 0)
  const submit = (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); const form = new FormData(event.currentTarget); const defaultCustomer = customers[0]; const taxable = Number(form.get("taxable")) || 0; const party = String(form.get("party") || defaultCustomer?.name); const customer = customers.find(item => item.name === party) ?? defaultCustomer; const invoice: Invoice = { id: editing?.id ?? `INV-${Date.now()}`, number: String(form.get("number")), party, gstin: String(form.get("gstin") || customer?.gstin), date: editing?.date ?? new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), taxable, rate: Number(form.get("rate")) || 18, kind, state: String(form.get("state")) === "Inter-state" ? "Inter-state" : "Intra-state", documentType: editing?.documentType ?? (kind === "Sales" ? "Sales Invoices" : "Purchase Invoices"), customerId: editing?.customerId ?? customer?.id, adjustment: editing?.adjustment, sourceUploadId: editing?.sourceUploadId }; if (editing) onUpdate(invoice); else onAdd(invoice); setShowForm(false); setEditing(null); event.currentTarget.reset() }
  return <>
    <InvoiceUploadManager customers={customers} uploads={uploads} defaultKind={kind} onAdd={onAddUpload} onUpdate={onUpdateUpload} onRemove={onRemoveUpload} onVerify={onVerifyUpload} notify={notify} />
    <div className="invoice-summary"><div className="invoice-total-card"><div><span>Total {kind.toLowerCase()} · {yearFilter}</span><strong>{formatINR(total)}</strong><small><ArrowUpRight size={13} /> 12.4% vs. last month</small></div><span className="invoice-total-icon"><Banknote size={20} /></span></div><div className="invoice-kpi"><span>Invoices recorded</span><strong>{visible.length.toString().padStart(2, "0")}</strong><small>For {yearFilter.toLowerCase()}</small></div><div className="invoice-kpi"><span>Taxable value</span><strong>{formatINR(visible.reduce((sum, invoice) => sum + invoice.taxable, 0))}</strong><small>Before GST</small></div><div className="invoice-kpi"><span>Validation status</span><strong className="validated-count"><CheckCircle2 size={17} /> {Math.max(0, visible.length - 1)} / {visible.length} valid</strong><small>1 needs review</small></div></div>
    <div className="toolbar-row invoice-filter-row"><div className="tab-switcher"><button className={kind === "Sales" ? "tab-active" : ""} onClick={() => setKind("Sales")}>Sales invoices</button><button className={kind === "Purchase" ? "tab-active" : ""} onClick={() => setKind("Purchase")}>Purchase invoices</button></div><div className="toolbar-controls invoice-filters"><label className="select-label">Customer<select className="select-button" value={customerFilter} onChange={event => setCustomerFilter(event.target.value)}><option value="All customers">All customers</option>{customers.map(customer => <option key={customer.id} value={customer.id}>{customer.name}</option>)}</select></label><label className="select-label">Invoice type<select className="select-button" value={typeFilter} onChange={event => setTypeFilter(event.target.value as InvoiceDocumentType | "All types")}><option value="All types">All types</option>{invoiceTypeOptions.map(type => <option key={type} value={type}>{type}</option>)}</select></label><label className="select-label">Financial year<select className="select-button" value={yearFilter} onChange={event => setYearFilter(event.target.value)}><option>All financial years</option>{yearOptions.map(year => <option key={year}>{year}</option>)}</select></label><Button onClick={() => { setEditing(null); setShowForm(value => !value) }}><Plus size={16} /> Add invoice</Button></div></div>
    {showForm && <Panel className="form-panel" title={`${editing ? "Edit" : "Add"} ${kind.toLowerCase()} invoice`} subtitle="Enter invoice details for the register" action={<button className="icon-button" aria-label="Close" onClick={() => setShowForm(false)}><X size={17} /></button>}><form className="customer-form" onSubmit={submit}><label className="form-field"><span>Invoice number *</span><input name="number" required placeholder="INV-2025-001" defaultValue={editing?.number} /></label><label className="form-field"><span>{kind === "Sales" ? "Customer name" : "Supplier name"}</span><input name="party" placeholder="Business name" defaultValue={editing?.party} /></label><label className="form-field"><span>GSTIN</span><input name="gstin" maxLength={15} placeholder="15-character GSTIN" defaultValue={editing?.gstin} /></label><label className="form-field"><span>Taxable amount *</span><input name="taxable" type="number" min="0" required placeholder="0.00" defaultValue={editing?.taxable} /></label><label className="form-field"><span>GST rate</span><select name="rate" defaultValue={String(editing?.rate ?? 18)}><option value="18">18%</option><option value="12">12%</option><option value="5">5%</option><option value="28">28%</option></select></label><label className="form-field"><span>Supply type</span><select name="state" defaultValue={editing?.state ?? "Intra-state"}><option>Intra-state</option><option>Inter-state</option></select></label><div className="form-actions field-wide"><Button type="button" variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button><Button type="submit">{editing ? "Update invoice" : "Save invoice"}</Button></div></form></Panel>}
    <Panel className="table-panel" title={`${kind} register`} subtitle={`${visible.length} invoices · ${yearFilter}`} action={<div className="search-field table-search"><Search size={15} /><input aria-label="Search invoices" placeholder="Search invoices..." value={search} onChange={event => setSearch(event.target.value)} /></div>}><div className="table-wrap"><table><thead><tr><th>Invoice no.</th><th>{kind === "Sales" ? "Customer" : "Supplier"}</th><th>GSTIN</th><th>Date</th><th>Taxable amount</th><th>GST</th><th>Total amount</th><th>Validation</th><th /></tr></thead><tbody>{visible.length ? visible.map((invoice, index) => { const tax = invoice.taxable * invoice.rate / 100; const sign = invoice.adjustment === "Credit" ? -1 : 1; return <tr key={invoice.id}><td className="mono-text strong-cell">{invoice.number}</td><td>{invoice.party}</td><td className="mono-text">{invoice.gstin}</td><td>{invoice.date}</td><td>{formatINR(invoice.taxable * sign)}</td><td>{invoice.rate}%</td><td className="strong-cell">{formatINR((invoice.taxable + tax) * sign)}</td><td><span className={`validation-tag ${index === visible.length - 1 ? "validation-warning" : ""}`}>{index === visible.length - 1 ? <CircleAlert size={13} /> : <CheckCircle2 size={13} />}{index === visible.length - 1 ? "Review" : "Valid"}</span></td><td><div className="row-actions"><button className="row-action" aria-label={`Edit ${invoice.number}`} onClick={() => { setEditing(invoice); setShowForm(true) }}><Pencil size={15} /></button><button className="row-action danger-text" aria-label={`Delete ${invoice.number}`} onClick={() => { if (window.confirm(`Delete invoice ${invoice.number}?`)) onRemove(invoice.id) }}><Trash2 size={15} /></button></div></td></tr> }) : <EmptyRow columns={9}>No {kind.toLowerCase()} invoices found.</EmptyRow>}</tbody></table></div><div className="table-foot"><span>Showing {visible.length} of {invoices.filter(invoice => invoice.kind === kind).length} invoices</span><div className="pagination"><button aria-label="Previous page"><ChevronLeft size={16} /></button><button className="page-current">1</button><button>2</button><button aria-label="Next page"><ChevronRight size={16} /></button></div></div></Panel>
  </>
}

type VerificationStatus = DocumentRecord["status"] | CustomerDocument["status"] | InvoiceUpload["status"]
type VerificationItem = {
  key: string
  id: string
  source: "legacy" | "customer" | "invoice"
  customer: string
  filename: string
  type: string
  date: string
  size: string
  status: VerificationStatus
  comment?: string
  file?: File
  invoiceReady?: boolean
}
type VerificationDecision = "Verified" | "Rejected" | "Correction needed"

export function VerificationView({ customers, documents, customerDocuments, invoiceUploads, onLegacyStatus, onUpdateCustomerDocument, onUpdateInvoiceUpload, onVerifyInvoiceUpload }: {
  customers: Customer[]
  documents: DocumentRecord[]
  customerDocuments: CustomerDocument[]
  invoiceUploads: InvoiceUpload[]
  onLegacyStatus: (id: string, status: DocumentRecord["status"], comment?: string) => void
  onUpdateCustomerDocument: (document: CustomerDocument) => void
  onUpdateInvoiceUpload: (upload: InvoiceUpload) => void
  onVerifyInvoiceUpload: (id: string) => void
}) {
  const [filter, setFilter] = useState("All")
  const [selected, setSelected] = useState<VerificationItem | null>(null)
  const [comment, setComment] = useState("")
  const [decision, setDecision] = useState<VerificationDecision | "">("")
  const customerNames = new Map(customers.map(customer => [customer.id, customer.name]))
  const allRows: VerificationItem[] = [
    ...documents.map(document => ({ key: `legacy:${document.id}`, id: document.id, source: "legacy" as const, customer: document.customer, filename: document.filename, type: document.type, date: document.date, size: document.size, status: document.status, comment: document.comment, file: document.file })),
    ...customerDocuments.map(document => ({ key: `customer:${document.id}`, id: document.id, source: "customer" as const, customer: customerNames.get(document.customerId) ?? "Unknown customer", filename: document.filename, type: `Customer · ${document.type}`, date: document.date, size: document.size, status: document.status, comment: document.comment, file: document.file })),
    ...invoiceUploads.map(upload => ({ key: `invoice:${upload.id}`, id: upload.id, source: "invoice" as const, customer: customerNames.get(upload.customerId) ?? "Unknown customer", filename: upload.filename, type: `Invoice · ${upload.type}`, date: upload.date, size: upload.size, status: upload.status, comment: upload.comment, file: upload.file, invoiceReady: Boolean(upload.fields.invoiceNumber.trim() && upload.fields.taxableAmount.trim()) })),
  ]
  const rows = allRows.filter(item => filter === "All" || item.status === filter)
  const pending = allRows.filter(item => item.status === "Pending" || item.status === "Needs review" || item.status === "Correction needed").length
  const verified = allRows.filter(item => item.status === "Verified").length
  const rejected = allRows.filter(item => item.status === "Rejected").length
  const complete = allRows.length ? Math.round((verified / allRows.length) * 100) : 0

  const quickVerify = (item: VerificationItem) => {
    if (item.source === "legacy") onLegacyStatus(item.id, "Verified")
    if (item.source === "customer") {
      const document = customerDocuments.find(candidate => candidate.id === item.id)
      if (document) onUpdateCustomerDocument({ ...document, status: "Verified", comment: undefined })
    }
    if (item.source === "invoice" && item.invoiceReady) onVerifyInvoiceUpload(item.id)
  }

  const finish = () => {
    if (!selected || !decision) return
    if ((decision === "Rejected" || decision === "Correction needed") && !comment.trim()) return
    if (selected.source === "legacy") onLegacyStatus(selected.id, decision, comment.trim() || undefined)
    if (selected.source === "customer") {
      const document = customerDocuments.find(candidate => candidate.id === selected.id)
      if (document) onUpdateCustomerDocument({ ...document, status: decision, comment: comment.trim() || undefined })
    }
    if (selected.source === "invoice") {
      if (decision === "Verified") onVerifyInvoiceUpload(selected.id)
      else {
        const upload = invoiceUploads.find(candidate => candidate.id === selected.id)
        if (upload) onUpdateInvoiceUpload({ ...upload, status: decision, comment: comment.trim() || undefined })
      }
    }
    setSelected(null)
    setDecision("")
    setComment("")
  }

  return <>
    <div className="verification-banner"><span className="verification-banner-icon"><ShieldCheck size={22} /></span><div><strong>Accuracy starts with a thorough review</strong><p>Review uploaded customer documents and invoice data before approving.</p></div><div className="verification-progress"><strong>{complete}%</strong><span>verified</span><div className="large-progress"><span style={{ width: `${complete}%` }} /></div></div></div>
    <div className="customer-summary-grid verify-stats"><div className="summary-mini"><span className="summary-icon tone-amber"><Clock3 size={17} /></span><div><strong>{pending}</strong><small>Awaiting review</small></div></div><div className="summary-mini"><span className="summary-icon tone-green"><CheckCircle2 size={17} /></span><div><strong>{verified}</strong><small>Verified</small></div></div><div className="summary-mini"><span className="summary-icon tone-red"><CircleAlert size={17} /></span><div><strong>{rejected}</strong><small>Rejected</small></div></div><div className="summary-mini"><span className="summary-icon tone-blue"><FileText size={17} /></span><div><strong>{allRows.length}</strong><small>Total documents</small></div></div></div>
    <Panel className="table-panel" title="Review queue" subtitle={`${pending} item${pending === 1 ? "" : "s"} awaiting a decision`} action={<select className="select-button" value={filter} onChange={event => setFilter(event.target.value)} aria-label="Filter verification status"><option>All</option><option>Needs review</option><option>Pending</option><option>Verified</option><option>Rejected</option><option>Correction needed</option></select>}><div className="table-wrap"><table><thead><tr><th>Customer</th><th>Document</th><th>Document type</th><th>Uploaded</th><th>Status</th><th>Action</th></tr></thead><tbody>{rows.length ? rows.map(item => <tr key={item.key}><td className="strong-cell">{item.customer}</td><td><div className="file-cell"><span className="file-icon"><FileText size={16} /></span><strong>{item.filename}</strong></div></td><td>{item.type}</td><td>{item.date}</td><td><Status value={item.status} />{item.comment && <small className="status-comment">{item.comment}</small>}</td><td><div className="row-actions"><button className="button button-secondary button-sm" onClick={() => { setSelected(item); setDecision(""); setComment(item.comment ?? "") }}><Eye size={14} /> Review</button>{item.status !== "Verified" && <button className="icon-button approve-icon" aria-label={`Quick verify ${item.filename}`} title={item.source === "invoice" && !item.invoiceReady ? "Complete invoice number and taxable amount in Invoice Management first" : "Verify document"} disabled={item.source === "invoice" && !item.invoiceReady} onClick={() => quickVerify(item)}><Check size={16} /></button>}</div></td></tr>) : <EmptyRow columns={6}>No documents match this status.</EmptyRow>}</tbody></table></div></Panel>
    {selected && <div className="modal-backdrop" role="presentation" onClick={event => { if (event.target === event.currentTarget) setSelected(null) }}><section className="decision-modal" role="dialog" aria-modal="true" aria-labelledby="review-title"><div className="modal-head"><div><h2 id="review-title">Review document</h2><p>{selected.customer} · {selected.type}</p></div><button className="icon-button" aria-label="Close review" onClick={() => setSelected(null)}><X size={18} /></button></div><div className="review-file"><FileText size={20} /><div><strong>{selected.filename}</strong><small>{selected.size} · Uploaded {selected.date}</small></div>{selected.file && <button className="review-preview" onClick={() => openFile(selected.file)}><Eye size={16} /> Preview</button>}</div>{selected.source === "invoice" && !selected.invoiceReady && <p className="review-validation-note">Add an invoice number and taxable amount in Invoice Management before verifying this invoice.</p>}<label className="form-field"><span>Decision</span><select value={decision} onChange={event => setDecision(event.target.value as VerificationDecision | "")}><option value="" disabled>Select a decision</option><option value="Verified">Verified</option><option value="Correction needed">Request correction</option><option value="Rejected">Reject document</option></select></label>{(decision === "Rejected" || decision === "Correction needed") && <label className="form-field"><span>Comment for customer <b>*</b></span><textarea value={comment} onChange={event => setComment(event.target.value)} placeholder="Describe the required correction..." rows={3} required /></label>}<div className="modal-actions"><Button variant="secondary" onClick={() => setSelected(null)}>Cancel</Button><Button onClick={finish} disabled={!decision || ((decision === "Rejected" || decision === "Correction needed") && !comment.trim()) || (selected.source === "invoice" && decision === "Verified" && !selected.invoiceReady)}>Save decision</Button></div></section></div>}
  </>
}

type GstScheme = "Monthly" | "QRMP" | "Composition"

type TaxPeriod = { label: string; start: string; end: string }

const monthlyTaxPeriods: TaxPeriod[] = [
  { label: "June 2025", start: "2025-06", end: "2025-07" },
  { label: "May 2025", start: "2025-05", end: "2025-06" },
  { label: "April 2025", start: "2025-04", end: "2025-05" },
]

const quarterlyTaxPeriods: TaxPeriod[] = [
  { label: "Q1 · Apr–Jun 2025", start: "2025-04", end: "2025-07" },
  { label: "Q4 · Jan–Mar 2025", start: "2025-01", end: "2025-04" },
  { label: "Q3 · Oct–Dec 2024", start: "2024-10", end: "2025-01" },
]

function invoiceMonthKey(dateText: string) {
  const isoDate = dateText.match(/^(\d{4})-(\d{2})/)
  if (isoDate) return `${isoDate[1]}-${isoDate[2]}`
  const date = new Date(dateText)
  if (Number.isNaN(date.getTime())) return ""
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
}

function monthlyPeriodFor(key: string): TaxPeriod {
  const [year, month] = key.split("-").map(Number)
  const startDate = new Date(year, month - 1, 1)
  const endDate = new Date(year, month, 1)
  return { label: startDate.toLocaleDateString("en-US", { month: "long", year: "numeric" }), start: key, end: `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, "0")}` }
}

function quarterlyPeriodFor(key: string): TaxPeriod {
  const [year, monthNumber] = key.split("-").map(Number)
  const month = monthNumber - 1
  const quarter = month >= 3 ? Math.floor((month - 3) / 3) + 1 : 4
  const startMonth = month >= 3 ? 3 + (quarter - 1) * 3 : 0
  const startDate = new Date(year, startMonth, 1)
  const endDate = new Date(year, startMonth + 3, 1)
  const finalMonth = new Date(endDate.getFullYear(), endDate.getMonth() - 1, 1)
  const monthName = (date: Date) => date.toLocaleDateString("en-US", { month: "short" })
  return { label: `Q${quarter} · ${monthName(startDate)}–${monthName(finalMonth)} ${finalMonth.getFullYear()}`, start: `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, "0")}`, end: `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, "0")}` }
}

function mergeTaxPeriods(existing: TaxPeriod[], generated: TaxPeriod[]) {
  return Array.from(new Map([...existing, ...generated].map(period => [period.start, period])).values()).sort((a, b) => b.start.localeCompare(a.start))
}

const schemeOptions: { value: GstScheme; description: string }[] = [
  { value: "Monthly", description: "Monthly GSTR-1 and GSTR-3B" },
  { value: "QRMP", description: "Quarterly returns, monthly payments" },
  { value: "Composition", description: "Quarterly CMP-08 · no ITC" },
]

export function CalculatorView({ customers, invoices }: { customers: Customer[]; invoices: Invoice[] }) {
  const invoiceMonths = Array.from(new Set(invoices.map(invoice => invoiceMonthKey(invoice.date)).filter(Boolean)))
  const monthlyOptions = mergeTaxPeriods(monthlyTaxPeriods, invoiceMonths.map(monthlyPeriodFor))
  const quarterlyOptions = mergeTaxPeriods(quarterlyTaxPeriods, invoiceMonths.map(quarterlyPeriodFor))
  const [scheme, setScheme] = useState<GstScheme>("Monthly")
  const [customer, setCustomer] = useState("All customers")
  const [period, setPeriod] = useState(monthlyOptions[0]?.label ?? "May 2025")
  const [compositionRate, setCompositionRate] = useState<1 | 5 | 6>(1)
  const [authorized, setAuthorized] = useState(false)
  const [adjustment, setAdjustment] = useState(0)
  const isComposition = scheme === "Composition"
  const periodOptions = scheme === "Monthly" ? monthlyOptions : quarterlyOptions
  const selectedPeriod = periodOptions.find(option => option.label === period) ?? periodOptions[0]
  const selectedCustomerId = customers.find(item => item.name === customer)?.id
  const filtered = invoices.filter(invoice => {
    const invoiceMonth = invoiceMonthKey(invoice.date)
    const matchesCustomer = customer === "All customers" || invoice.customerId === selectedCustomerId || invoice.party === customer
    return invoiceMonth >= selectedPeriod.start && invoiceMonth < selectedPeriod.end && matchesCustomer
  })
  const sales = filtered.filter(invoice => invoice.kind === "Sales")
  const purchases = filtered.filter(invoice => invoice.kind === "Purchase")
  const adjustmentSign = (invoice: Invoice) => invoice.adjustment === "Credit" ? -1 : 1
  const tax = (invoice: Invoice) => invoice.taxable * invoice.rate / 100 * adjustmentSign(invoice)
  const taxableSales = sales.reduce((sum, invoice) => sum + invoice.taxable * adjustmentSign(invoice), 0)
  const output = sales.reduce((sum, invoice) => sum + tax(invoice), 0)
  const input = purchases.reduce((sum, invoice) => sum + tax(invoice), 0)
  const eligible = isComposition ? 0 : input * .85
  const compositionLevy = taxableSales * compositionRate / 100
  const payable = Math.max(0, (isComposition ? compositionLevy : output - eligible) + (authorized ? adjustment : 0))
  const selectScheme = (nextScheme: GstScheme) => {
    setScheme(nextScheme)
    setPeriod(nextScheme === "Monthly" ? monthlyOptions[0]?.label ?? "May 2025" : quarterlyOptions[0]?.label ?? quarterlyTaxPeriods[0].label)
    setAuthorized(false)
    setAdjustment(0)
  }
  const exportSummary = () => downloadCsv("gst-calculation-summary.csv", [
    ["Scheme", scheme],
    ["Tax period", period],
    [isComposition ? "Taxable turnover" : "Output GST", isComposition ? taxableSales : output],
    [isComposition ? "Composition rate" : "Eligible ITC", isComposition ? `${compositionRate}%` : eligible],
    [isComposition ? "Composition levy" : "Net GST payable", payable],
  ])

  return <>
    <fieldset className="calc-scheme-group">
      <legend>Filing scheme</legend>
      <div className="calc-scheme-options">
        {schemeOptions.map(option => <label className="calc-scheme-option" key={option.value}>
          <input type="radio" name="gst-scheme" value={option.value} checked={scheme === option.value} onChange={() => selectScheme(option.value)} />
          <span className="calc-scheme-name">{option.value}</span>
          <span className="calc-scheme-description">{option.description}</span>
        </label>)}
      </div>
    </fieldset>

    <div className="toolbar-row calc-filters">
      <div className="toolbar-controls">
        <label className="select-label">Customer<select className="select-button" value={customer} onChange={event => setCustomer(event.target.value)}><option>All customers</option>{customers.map(item => <option key={item.id}>{item.name}</option>)}</select></label>
        <label className="select-label">{scheme === "Monthly" ? "Tax month" : "Tax quarter"}<select className="select-button" value={period} onChange={event => setPeriod(event.target.value)}>{periodOptions.map(option => <option key={option.label}>{option.label}</option>)}</select></label>
        {isComposition && <label className="select-label">Business category<select className="select-button" value={compositionRate} onChange={event => setCompositionRate(Number(event.target.value) as 1 | 5 | 6)}><option value={1}>Trade / manufacturer · 1%</option><option value={5}>Restaurant service · 5%</option><option value={6}>Service provider · 6%</option></select></label>}
      </div>
      <Button variant="secondary" onClick={exportSummary}><Download size={15} /> Export summary</Button>
    </div>

    <div className="calc-overview">
      <div className="calc-total-card">
        <div className="calc-card-top"><span>{isComposition ? "Estimated composition levy" : "Estimated net GST payable"}</span><span className="calc-card-icon"><Banknote size={19} /></span></div>
        <strong>{formatINR(payable)}</strong>
        <p>For {customer === "All customers" ? "all customers" : customer} · {period}</p>
        <div className="calc-total-footer"><span>{scheme} scheme · sample invoice data</span><span className="estimate-pill"><i /> Estimate</span></div>
      </div>
      <div className="calc-side-stats">
        <div className="calc-side-card"><span className="calc-side-icon output-icon"><ArrowUpRight size={17} /></span><span><small>{isComposition ? "Composition levy" : "Output GST"}</small><strong>{formatINR(isComposition ? compositionLevy : output)}</strong><em>{isComposition ? `${compositionRate}% of taxable sales` : `From ${sales.length} sales invoices`}</em></span></div>
        <div className="calc-side-card"><span className="calc-side-icon input-icon"><ArrowDownLeft size={17} /></span><span><small>Eligible input tax credit</small><strong>{isComposition ? "Not eligible" : formatINR(eligible)}</strong><em>{isComposition ? "Not claimable in this scheme" : "85% of recorded purchase tax"}</em></span></div>
        <div className="calc-side-card"><span className="calc-side-icon neutral-icon"><FileSpreadsheet size={17} /></span><span><small>Taxable sales</small><strong>{formatINR(taxableSales)}</strong><em>Across {sales.length} invoices</em></span></div>
      </div>
    </div>

    <div className="calc-details-grid">
      <Panel title={isComposition ? "Composition levy summary" : "Liability summary"} subtitle={isComposition ? "Illustrative turnover-based estimate for the selected quarter" : "Net GST calculation for the selected period"}>
        <div className="liability-rows">
          {isComposition ? <>
            <div><span>Taxable turnover</span><strong>{formatINR(taxableSales)}</strong></div>
            <div><span>Illustrative composition rate</span><strong>{compositionRate}%</strong></div>
            <div className="liability-sub"><span>Input tax credit</span><span>Not eligible</span></div>
          </> : <>
            <div><span>Output GST on sales</span><strong>{formatINR(output)}</strong></div>
            <div className="liability-sub"><span>CGST + SGST · intra-state</span><span>{formatINR(sales.filter(invoice => invoice.state === "Intra-state").reduce((sum, invoice) => sum + tax(invoice), 0))}</span></div>
            <div className="liability-sub"><span>IGST · inter-state</span><span>{formatINR(sales.filter(invoice => invoice.state === "Inter-state").reduce((sum, invoice) => sum + tax(invoice), 0))}</span></div>
            <div><span>Eligible input tax credit</span><strong className="green-value">− {formatINR(eligible)}</strong></div>
            <div className="liability-sub"><span>Input tax recorded</span><span>{formatINR(input)}</span></div>
          </>}
          {authorized && <div><span>Authorized adjustment</span><label className="adjust-field">₹ <input type="number" value={adjustment} onChange={event => setAdjustment(Number(event.target.value))} aria-label="Authorized manual adjustment" /></label></div>}
          <div className="liability-total"><strong>{isComposition ? "Estimated levy payable" : "Net GST payable"}</strong><strong>{formatINR(payable)}</strong></div>
        </div>
        <div className="adjustment-note"><ShieldCheck size={16} /><span>Manual adjustment</span><label className="toggle"><input type="checkbox" checked={authorized} onChange={event => setAuthorized(event.target.checked)} /><i /></label><small>{authorized ? "Authorized" : "Requires authorization"}</small></div>
      </Panel>

      {isComposition ? <Panel title="Composition rate" subtitle="Rate applied to taxable turnover in this estimate">
        <div className="composition-rate-display"><strong>{compositionRate}%</strong><span>{compositionRate === 1 ? "Trade / manufacturer" : compositionRate === 5 ? "Restaurant service" : "Service provider"}</span></div>
        <div className="composition-callout"><CircleAlert size={16} /><span>Composition eligibility and applicable rates depend on your business and current GST rules. Confirm with a tax professional before filing.</span></div>
      </Panel> : <Panel title="GST split by rate" subtitle="Estimated liability across taxable supplies">
        <div className="rate-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={[{ rate: "5%", output: output * .12 }, { rate: "12%", output: output * .24 }, { rate: "18%", output: output * .58 }, { rate: "28%", output: output * .06 }]} margin={{ top: 10, right: 8, left: -20, bottom: 0 }}><defs><linearGradient id="taxFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#237d67" stopOpacity={0.17} /><stop offset="95%" stopColor="#237d67" stopOpacity={0} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#edf0f3" strokeDasharray="4 4" /><XAxis dataKey="rate" axisLine={false} tickLine={false} tick={{ fill: "#9299a5", fontSize: 11 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#9299a5", fontSize: 10 }} /><Tooltip /><Area type="monotone" dataKey="output" stroke="#237d67" fill="url(#taxFill)" strokeWidth={2} isAnimationActive={false} /></AreaChart></ResponsiveContainer></div>
        <div className="rate-legend"><span><i className="legend-filed" />Output tax by rate</span><strong>{formatINR(output)}</strong></div>
      </Panel>}
    </div>

    <Panel className="table-panel" title={isComposition ? "Sales-wise composition estimate" : "Invoice-wise calculation"} subtitle={isComposition ? "Composition levy calculated on sales turnover; no GST is charged separately" : "Tax calculation breakdown for the current period"}>
      <div className="table-wrap"><table>
        {isComposition ? <>
          <thead><tr><th>Invoice no.</th><th>Customer</th><th>Taxable turnover</th><th>Illustrative rate</th><th>Estimated levy</th></tr></thead>
          <tbody>{sales.length ? sales.map(invoice => <tr key={invoice.id}><td className="mono-text strong-cell">{invoice.number}</td><td>{invoice.party}</td><td>{formatINR(invoice.taxable)}</td><td>{compositionRate}%</td><td className="strong-cell">{formatINR(invoice.taxable * compositionRate / 100 * adjustmentSign(invoice))}</td></tr>) : <EmptyRow columns={5}>No sales invoices in this period.</EmptyRow>}</tbody>
        </> : <>
          <thead><tr><th>Invoice no.</th><th>Customer / supplier</th><th>Supply</th><th>Taxable value</th><th>Rate</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Total GST</th></tr></thead>
          <tbody>{filtered.length ? filtered.map(invoice => { const amount = tax(invoice); const intra = invoice.state === "Intra-state"; return <tr key={invoice.id}><td className="mono-text strong-cell">{invoice.number}</td><td>{invoice.party}</td><td><span className={`supply-tag ${invoice.kind === "Sales" ? "supply-sales" : "supply-purchase"}`}>{invoice.kind}</span></td><td>{formatINR(invoice.taxable)}</td><td>{invoice.rate}%</td><td>{intra ? formatINR(amount / 2) : "—"}</td><td>{intra ? formatINR(amount / 2) : "—"}</td><td>{!intra ? formatINR(amount) : "—"}</td><td className="strong-cell">{formatINR(amount)}</td></tr> }) : <EmptyRow columns={9}>No invoices in this period.</EmptyRow>}</tbody>
        </>}
      </table></div>
      <p className="table-disclaimer">Estimates use sample data and simplified assumptions. Check eligibility, rates, and calculations against current GST rules before filing.</p>
    </Panel>
  </>
}

export function ReturnsView() {
  const [filter, setFilter] = useState("All returns")
  const [selected, setSelected] = useState<(typeof returnRows)[number] | null>(null)
  const rows = returnRows.filter(row => filter === "All returns" || row.status === filter)
  const counts = ["Not started", "In progress", "Ready for review", "Pending payment", "Filed"]
  return <>
    <div className="return-notice"><span><CircleAlert size={18} /></span><div><strong>Filing is not connected</strong><p>This frontend demo can prepare summaries, but cannot submit GST returns or generate a real ARN.</p></div></div>
    <div className="return-summary-grid">{counts.map((status, index) => <div className="return-summary" key={status}><span className={`return-summary-icon return-sum-${index}`}><FileCheck2 size={17} /></span><small>{status}</small><strong>{returnRows.filter(row => row.status === status).length}</strong></div>)}</div>
    <div className="toolbar-row"><div className="period-label"><CalendarDays size={17} /><strong>May 2025</strong><button aria-label="Previous month"><ChevronLeft size={15} /></button><button aria-label="Next month"><ChevronRight size={15} /></button></div><div className="toolbar-controls"><select className="select-button" aria-label="Filter return status" value={filter} onChange={event => setFilter(event.target.value)}><option>All returns</option>{counts.map(status => <option key={status}>{status}</option>)}</select><Button variant="secondary" onClick={() => downloadCsv("gst-return-summary.csv", [["Customer", "GSTIN", "Return", "Period", "Due date", "Status"], ...rows.map(row => [row.customer, row.gstin, row.type, row.period, row.due, row.status])])}><Download size={15} /> Download summary</Button></div></div>
    <Panel className="table-panel" title="Return register" subtitle={`${rows.length} returns · Financial year 2025–26`}><div className="table-wrap"><table><thead><tr><th>Customer</th><th>GSTIN</th><th>Return type</th><th>Tax period</th><th>Filing due date</th><th>Status</th><th>Details</th></tr></thead><tbody>{rows.map((row, index) => <tr key={`${row.gstin}-${row.type}`}><td className="strong-cell">{row.customer}</td><td className="mono-text">{row.gstin}</td><td><span className="return-type-pill">{row.type}</span></td><td>{row.period}</td><td>{row.due}</td><td><Status value={row.status} /></td><td><button className="text-link" onClick={() => setSelected(row)}>Review <ArrowRight size={13} /></button></td></tr>)}</tbody></table></div></Panel>
    <Panel className="history-panel" title="Filing history" subtitle="Return summaries staged for review; submission is not connected"><div className="history-row"><span className="history-check"><FileText size={14} /></span><div><strong>GSTR-1 · Northstar Digital</strong><small>April 2025 · Prepared for review · Not filed</small></div><Status value="Ready for review" /><span className="history-date">May 10, 2025</span></div><div className="history-row"><span className="history-check"><FileText size={14} /></span><div><strong>GSTR-3B · Aarav Textiles Pvt. Ltd.</strong><small>April 2025 · Prepared for review · Not filed</small></div><Status value="Ready for review" /><span className="history-date">May 18, 2025</span></div></Panel>
    {selected && <div className="modal-backdrop" onClick={event => { if (event.target === event.currentTarget) setSelected(null) }}><section className="decision-modal" role="dialog" aria-modal="true" aria-labelledby="return-summary-title"><div className="modal-head"><div><h2 id="return-summary-title">{selected.type} return summary</h2><p>{selected.customer} · {selected.period}</p></div><button className="icon-button" aria-label="Close summary" onClick={() => setSelected(null)}><X size={18} /></button></div><div className="return-detail-list"><div><span>GSTIN</span><strong className="mono-text">{selected.gstin}</strong></div><div><span>Financial year</span><strong>2025–26</strong></div><div><span>Filing due date</span><strong>{selected.due}</strong></div><div><span>Current status</span><Status value={selected.status} /></div></div><div className="return-notice small-notice"><span><CircleAlert size={17} /></span><div><strong>Review only</strong><p>Successful filing and ARN must be confirmed by an authorized GST integration.</p></div></div><div className="modal-actions"><Button variant="secondary" onClick={() => setSelected(null)}>Close</Button><Button onClick={() => window.print()}><FileDown size={15} /> Print summary</Button></div></section></div>}
  </>
}

export function ReportsView({ customers, invoices }: { customers: Customer[]; invoices: Invoice[] }) {
  const reportRows = [
    { title: "Customer-wise GST summary", description: "Output tax, eligible ITC and net liability by customer", icon: UsersRound, label: "GST SUMMARY", count: `${customers.length} customers`, key: "customer" },
    { title: "Monthly sales report", description: "Sales register by invoice, customer and tax rate", icon: ArrowUpRight, label: "SALES", count: `${invoices.filter(invoice => invoice.kind === "Sales").length} invoices`, key: "sales" },
    { title: "Monthly purchase report", description: "Purchases and input tax by supplier", icon: ArrowDownLeft, label: "PURCHASES", count: `${invoices.filter(invoice => invoice.kind === "Purchase").length} invoices`, key: "purchases" },
    { title: "Input tax credit report", description: "Recorded purchase tax and estimated eligible ITC", icon: FileSpreadsheet, label: "INPUT TAX", count: "May 2025", key: "itc" },
    { title: "Filing history", description: "GST return statuses and filing date history", icon: FileCheck2, label: "COMPLIANCE", count: `${returnRows.length} returns`, key: "returns" },
    { title: "Document verification", description: "Customer document collection and review progress", icon: ShieldCheck, label: "DOCUMENTS", count: "All customers", key: "documents" },
  ]
  const doExport = (key: string) => { const selected = key === "sales" ? invoices.filter(invoice => invoice.kind === "Sales") : key === "purchases" ? invoices.filter(invoice => invoice.kind === "Purchase") : invoices; const rows = [["Invoice", "Customer / supplier", "GSTIN", "Date", "Taxable amount", "Rate", "Kind"], ...selected.map(invoice => [invoice.number, invoice.party, invoice.gstin, invoice.date, invoice.taxable, invoice.rate, invoice.kind])]; downloadCsv(`${key}-report-may-2025.csv`, rows) }
  return <><div className="report-intro"><div><span className="report-intro-icon"><ChartNoAxesCombined size={19} /></span><div><strong>Reports that make compliance clearer</strong><p>Explore your portfolio data with ready-to-export summaries.</p></div></div><div className="toolbar-controls"><select className="select-button" aria-label="Select report period"><option>May 2025</option><option>April 2025</option><option>March 2025</option></select><Button variant="secondary" onClick={() => window.print()}><FileDown size={15} /> Print / PDF</Button></div></div><div className="reports-grid">{reportRows.map(({ title, description, icon: Icon, label, count, key }, index) => <article className="report-card" key={title}><div className="report-card-top"><span className={`report-icon report-icon-${index}`}><Icon size={18} /></span><button className="icon-button" aria-label={`Download ${title}`} onClick={() => doExport(key)}><Download size={16} /></button></div><span className="report-label">{label}</span><h2>{title}</h2><p>{description}</p><div className="report-card-foot"><span>{count}</span><button className="text-link" onClick={() => doExport(key)}>Export <ArrowRight size={14} /></button></div></article>)}</div><div className="report-note"><CircleAlert size={16} /><span>Reports use sample data and are intended for workflow demonstration, not tax advice.</span></div></>
}

export function SettingsView({ notify }: { notify: (message: string) => void }) {
  const [section, setSection] = useState("Company profile")
  const [employees, setEmployees] = useState([{ name: "Riya Mehta", email: "riya@atlasandco.in", role: "Admin", initials: "RM" }, { name: "Vikram Desai", email: "vikram@atlasandco.in", role: "Tax professional", initials: "VD" }, { name: "Pooja Nair", email: "pooja@atlasandco.in", role: "Reviewer", initials: "PN" }])
  const [inviteOpen, setInviteOpen] = useState(false)
  const [email, setEmail] = useState("")
  const sections = ["Company profile", "Team & access", "Notifications", "Security"]
  return <div className="settings-layout"><nav className="settings-nav" aria-label="Settings sections">{sections.map((item, index) => <button key={item} className={section === item ? "settings-active" : ""} onClick={() => setSection(item)}>{[Building2, UsersRound, Bell, ShieldCheck].map((Icon, i) => i === index ? <Icon size={16} key={i} /> : null)}{item}</button>)}</nav><div className="settings-content">{section === "Company profile" && <Panel title="Company profile" subtitle="Business details used across your GST workspace"><form className="customer-form settings-form" onSubmit={event => { event.preventDefault(); notify("Company profile saved.") }}><label className="form-field field-wide"><span>Company name</span><input defaultValue="Atlas & Co. Chartered Accountants" /></label><label className="form-field"><span>GSTIN</span><input defaultValue="27AAEFA1234B1ZP" /></label><label className="form-field"><span>Contact email</span><input type="email" defaultValue="hello@atlasandco.in" /></label><label className="form-field"><span>Business phone</span><input defaultValue="+91 22 4000 1234" /></label><label className="form-field"><span>State</span><select defaultValue="Maharashtra"><option>Maharashtra</option><option>Karnataka</option><option>Delhi</option></select></label><label className="form-field field-wide"><span>Registered address</span><input defaultValue="Fort, Mumbai, Maharashtra 400001" /></label><div className="form-actions field-wide"><Button type="submit">Save changes</Button></div></form></Panel>}{section === "Team & access" && <Panel title="Team & access" subtitle="Manage people and permissions for your practice" action={<Button onClick={() => setInviteOpen(value => !value)}><Plus size={15} /> Invite employee</Button>}>{inviteOpen && <form className="invite-form" onSubmit={event => { event.preventDefault(); if (!email.includes("@")) return; setEmployees(previous => [...previous, { name: email.split("@")[0], email, role: "Reviewer", initials: email.slice(0, 2).toUpperCase() }]); setEmail(""); setInviteOpen(false); notify("Employee invited to the demo workspace.") }}><input aria-label="Employee email" type="email" required placeholder="name@company.com" value={email} onChange={event => setEmail(event.target.value)} /><select aria-label="New employee role"><option>Reviewer</option><option>Tax professional</option><option>Admin</option></select><Button type="submit">Send invite</Button></form>}<div className="team-list">{employees.map((employee, index) => <div className="team-row" key={employee.email}><span className={`initials initials-${["blue", "green", "orange"][index % 3]}`}>{employee.initials}</span><span className="team-person"><strong>{employee.name}</strong><small>{employee.email}</small></span>{employee.role === "Admin" ? <Status value="Active" /> : <select className="role-select" value={employee.role} onChange={event => setEmployees(previous => previous.map(person => person.email === employee.email ? { ...person, role: event.target.value } : person))} aria-label={`Role for ${employee.name}`}><option>Tax professional</option><option>Reviewer</option><option>Admin</option></select>}<button className="row-action" aria-label={`More options for ${employee.name}`}><ChevronDown size={16} /></button></div>)}</div></Panel>}{section === "Notifications" && <Panel title="Notification preferences" subtitle="Choose which workspace updates you receive">{["Upcoming filing deadlines", "Document uploads from customers", "Verification requests", "Return status updates", "Weekly compliance summary"].map((label, index) => <div className="preference-row" key={label}><span><strong>{label}</strong><small>{index === 4 ? "A weekly digest for your practice" : "Email and in-app notification"}</small></span><label className="toggle"><input type="checkbox" defaultChecked={index !== 3} aria-label={label} /><i /></label></div>)}<div className="form-actions"><Button onClick={() => notify("Notification preferences saved.")}>Save preferences</Button></div></Panel>}{section === "Security" && <Panel title="Security & access" subtitle="Protect your workspace and manage sign-in preferences"><div className="security-card"><span className="security-icon"><ShieldCheck size={19} /></span><div><strong>Password management</strong><p>Update your sign-in password regularly.</p></div><Button variant="secondary" onClick={() => notify("Password settings are available when authentication is connected.")}>Manage password</Button></div><div className="security-card"><span className="security-icon"><UsersRound size={19} /></span><div><strong>Role-based access</strong><p>Team members have permissions based on their role.</p></div><Button variant="secondary" onClick={() => setSection("Team & access")}>Manage roles</Button></div><p className="settings-disclaimer">Authentication and access control require a connected backend. This frontend demo does not provide secure sign-in.</p><div className="auth-shortcuts"><a className="button button-secondary" href="/login">Preview sign-in screen</a><a className="button button-secondary" href="/register">Preview registration</a></div></Panel>}</div></div>
}

export function ProfileView({ customer, documents, invoices, onNavigate }: { customer: Customer; documents: DocumentRecord[]; invoices: Invoice[]; onNavigate: (page: PageId) => void }) {
  const [tab, setTab] = useState("Overview")
  const tabs = ["Overview", "Documents", "Sales invoices", "Purchase invoices", "Verification", "GST calculation", "GST returns", "Filing history"]
  const salesCount = invoices.filter(invoice => invoice.kind === "Sales").length
  return <><button className="back-link" onClick={() => onNavigate("customers")}><ChevronLeft size={15} /> Back to customers</button><div className="profile-header"><Initials customer={customer} /><div className="profile-heading"><div><h2>{customer.name}</h2><Status value={customer.status} /></div><p>{customer.business} · {customer.city}, {customer.state}</p></div><Button variant="secondary" onClick={() => onNavigate("customers")}>Customer list</Button></div><div className="profile-tabs">{tabs.map(item => <button key={item} className={tab === item ? "profile-tab-active" : ""} onClick={() => setTab(item)}>{item}</button>)}</div>{tab === "Overview" && <div className="profile-grid"><Panel title="Customer details" subtitle="Business and contact information"><div className="profile-details"><div><small>Customer ID</small><strong>{customer.id}</strong></div><div><small>GSTIN</small><strong className="mono-text">{customer.gstin}</strong></div><div><small>Business type</small><strong>{customer.business}</strong></div><div><small>Primary contact</small><strong>{customer.contact}</strong></div><div><small>Email</small><strong>{customer.email}</strong></div><div><small>Location</small><strong>{customer.city}, {customer.state}</strong></div></div></Panel><Panel title="Compliance overview" subtitle="Collection and filing progress"><div className="profile-completion"><strong>{customer.completion}%</strong><span>Profile completion</span></div><div className="large-progress"><span style={{ width: `${customer.completion}%` }} /></div><div className="profile-mini-stats"><div><small>Documents</small><strong>{documents.length}</strong></div><div><small>Invoices</small><strong>{invoices.length}</strong></div><div><small>Sales invoices</small><strong>{salesCount}</strong></div></div><button className="text-link" onClick={() => onNavigate("calculator")}>Open GST calculation <ArrowRight size={14} /></button></Panel></div>}{tab === "Documents" || tab === "Verification" ? <Panel title={tab} subtitle={`${documents.length} documents on file`}><div className="simple-list">{documents.map(item => <div key={item.id}><FileText size={16} /><span><strong>{item.filename}</strong><small>{item.type} · {item.date}</small></span><Status value={item.status} /></div>)}{documents.length === 0 && <p className="empty-row">No documents have been added yet.</p>}</div></Panel> : null}{tab === "Sales invoices" || tab === "Purchase invoices" ? <Panel title={tab} subtitle="Invoices recorded for this customer"><div className="table-wrap"><table><thead><tr><th>Invoice</th><th>Date</th><th>Taxable amount</th><th>GST rate</th><th>Supply</th></tr></thead><tbody>{invoices.filter(invoice => invoice.kind === (tab === "Sales invoices" ? "Sales" : "Purchase")).map(invoice => <tr key={invoice.id}><td className="mono-text">{invoice.number}</td><td>{invoice.date}</td><td>{formatINR(invoice.taxable)}</td><td>{invoice.rate}%</td><td>{invoice.state}</td></tr>)}</tbody></table></div></Panel> : null}{["GST calculation", "GST returns", "Filing history"].includes(tab) && <Panel title={tab} subtitle={`Tax period May 2025 · ${customer.name}`}><div className="profile-tab-empty"><span className="profile-tab-icon"><FileCheck2 size={20} /></span><strong>{tab === "GST returns" ? "Return preparation" : tab}</strong><p>Open the corresponding workspace module to review this customer’s {tab.toLowerCase()} sample data.</p><Button variant="secondary" onClick={() => onNavigate(tab === "GST calculation" ? "calculator" : "returns")}>Open {tab.toLowerCase()} <ArrowRight size={14} /></Button></div></Panel>}</>}
