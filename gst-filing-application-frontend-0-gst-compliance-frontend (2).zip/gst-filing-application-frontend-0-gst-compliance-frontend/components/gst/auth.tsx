"use client"

import { useState } from "react"
import Link from "next/link"
import { Activity, ArrowLeft, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react"

export function AuthScreen({ mode }: { mode: "login" | "register" }) {
  const isLogin = mode === "login"
  const [notice, setNotice] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [forgot, setForgot] = useState(false)

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setNotice("Authentication is not connected in this frontend demo. No credentials were sent or saved.")
  }

  return <main className="auth-page">
    <section className="auth-story">
      <Link href="/" className="auth-brand"><span className="auth-brand-mark"><Activity size={20} /></span><span><strong>ledgerly</strong><small>GST workspace</small></span></Link>
      <div className="auth-story-copy"><span className="auth-overline"><ShieldCheck size={14} /> BUILT FOR ACCOUNTING TEAMS</span><h1>Compliance, made<br />clearer.</h1><p>Keep customer records, documents and GST calculations organized in this frontend-only demo.</p><div className="auth-story-card"><span className="auth-story-card-icon"><LockKeyhole size={17} /></span><div><strong>Your work, thoughtfully organized</strong><small>One workspace for every filing milestone.</small></div><span className="auth-story-check">✓</span></div></div>
      <div className="auth-story-footer"><span>© 2025 Ledgerly workspace</span><span>No filings or payments submitted</span></div>
      <div className="auth-decor auth-decor-one" /><div className="auth-decor auth-decor-two" />
    </section>
    <section className="auth-main">
      <Link href="/" className="auth-back"><ArrowLeft size={15} /> Back to workspace preview</Link>
      <div className="auth-card">
        <div className="auth-card-heading"><span className="auth-lock"><LockKeyhole size={19} /></span><h2>{forgot ? "Reset your password" : isLogin ? "Welcome back" : "Create your account"}</h2><p>{forgot ? "Enter your work email to request a reset." : isLogin ? "Sign in to manage your GST workspace." : "Start organizing your GST compliance workflow."}</p></div>
        {notice && <div className="auth-notice" role="status">{notice}</div>}
        <form className="auth-form" onSubmit={submit}>
          {!isLogin && !forgot && <label className="auth-field"><span>Full name</span><input name="name" autoComplete="name" required placeholder="Your name" /></label>}
          <label className="auth-field"><span>Work email</span><input name="email" type="email" autoComplete="email" required placeholder="you@company.com" /></label>
          {!forgot && <label className="auth-field"><span>Password</span><span className="auth-password"><input name="password" type={showPassword ? "text" : "password"} autoComplete={isLogin ? "current-password" : "new-password"} required minLength={8} placeholder="At least 8 characters" /><button type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword(value => !value)}>{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>}
          {isLogin && !forgot && <button type="button" className="auth-forgot" onClick={() => { setForgot(true); setNotice("") }}>Forgot password?</button>}
          <button type="submit" className="auth-submit">{forgot ? "Request password reset" : isLogin ? "Sign in" : "Create account"}</button>
        </form>
        <div className="auth-disclaimer"><LockKeyhole size={13} /><span>Authentication is a frontend placeholder; no credentials are stored or transmitted.</span></div>
        <div className="auth-switch">{forgot ? <button onClick={() => { setForgot(false); setNotice("") }}>Back to sign in</button> : isLogin ? <span>New to Ledgerly? <Link href="/register">Create an account</Link></span> : <span>Already have an account? <Link href="/login">Sign in</Link></span>}</div>
      </div>
      <p className="auth-terms">By continuing, you agree to the <a href="#terms">Terms of Service</a> and <a href="#privacy">Privacy Policy</a>.</p>
    </section>
  </main>
}
